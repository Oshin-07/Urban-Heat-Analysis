"""Central configuration: paths and constants used by every script."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RAW_DIR = ROOT / "data" / "raw"
PROC_DIR = ROOT / "data" / "processed"
FIG_DIR = ROOT / "outputs" / "figures"
MODEL_DIR = ROOT / "outputs" / "models"
METRIC_DIR = ROOT / "outputs" / "metrics"

# Raw files (exactly as supplied in ML_Dataset.zip)
RAW_FILES = {
    "lst": "LST_Final_V3.csv",
    "no2": "NO2_Final_V3.csv",
    "wind": "Wind_Final_V3.csv",
}

CITIES = ["Delhi", "Bangalore"]
ZONES = ["Urban", "Rural"]

# Outlier rule (see README / report): rolling-median based
ROLL_WINDOW = 15            # days, centred
OUTLIER_THRESHOLD_C = 10.0  # degrees C

# Chronological split: train/tune on years <= TRAIN_END_YEAR, test on TEST_YEAR
TRAIN_END_YEAR = 2024
TEST_YEAR = 2025
CV_VALIDATION_YEARS = [2022, 2023, 2024]  # expanding-window folds
SEED = 42

# Colour-blind-safe palette (Okabe-Ito)
CITY_COLORS = {"Delhi": "#D55E00", "Bangalore": "#0072B2"}

# Approximate city-centre reference points (NOT from the dataset; used only
# for a labelled reference map in the dashboard).
CITY_CENTRES = {"Delhi": (28.6139, 77.2090), "Bangalore": (12.9716, 77.5946)}
