"""Urban Heat Analysis helpers (data cleaning, features, modelling)."""
