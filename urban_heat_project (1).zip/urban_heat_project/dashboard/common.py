"""Streamlit helpers shared by all pages: cached loaders, page header, synced city selection."""
from __future__ import annotations

import json

import joblib
import pandas as pd
import streamlit as st

from uhi import config as C

from . import theme as T

CITY_KEY = "sel_city"  # the one place the selected city is stored
_PICKER_KEYS = ("pick_overview", "pick_explore", "pick_compare")


# ----------------------------------------------------------------- loaders
@st.cache_data(show_spinner="Loading cleaned dataset…")
def load_data() -> pd.DataFrame | None:
    p = C.PROC_DIR / "lst_long_clean.csv"
    if not p.exists():
        return None
    return pd.read_csv(p, parse_dates=["date"])


@st.cache_data
def load_csv(name: str) -> pd.DataFrame | None:
    p = C.METRIC_DIR / name
    return pd.read_csv(p) if p.exists() else None


@st.cache_data
def load_json(name: str) -> dict | None:
    p = C.METRIC_DIR / name
    return json.loads(p.read_text()) if p.exists() else None


@st.cache_resource(show_spinner="Loading trained model…")
def load_model():
    p = C.MODEL_DIR / "best_model.joblib"
    return joblib.load(p) if p.exists() else None


def need_data() -> pd.DataFrame:
    df = load_data()
    if df is None:
        st.error("Cleaned dataset not found. In the project folder run `python 01_clean_data.py`, then refresh this page.")
        st.stop()
    return df


# --------------------------------------------------------------- selection
def get_city(cities: list[str]) -> str:
    c = st.session_state.get(CITY_KEY)
    if c not in cities:
        c = cities[0]
        st.session_state[CITY_KEY] = c
    return c


def set_city(city: str) -> None:
    """Change the selected city everywhere (also resets any picker widgets already created)."""
    st.session_state[CITY_KEY] = city
    for k in _PICKER_KEYS:
        if k in st.session_state:
            st.session_state[k] = city


def city_picker(cities: list[str], key: str, label: str = "City", pills: bool = False) -> str:
    """A city control that stays in sync with the map and with the other pages."""
    current = get_city(cities)

    def _changed() -> None:
        v = st.session_state.get(key)
        if v in cities:
            st.session_state[CITY_KEY] = v

    st.session_state.setdefault(key, current)
    if st.session_state[key] != current:
        st.session_state[key] = current
    if pills:
        st.segmented_control(label, cities, key=key, on_change=_changed, selection_mode="single")
    else:
        st.selectbox(label, cities, key=key, on_change=_changed, help="Type to search.")
    return get_city(cities)


def map_click_handler(map_key: str, cities: list[str]):
    """Return a callback for plotly_chart(on_select=...) that turns a marker click into a city choice."""
    def _cb() -> None:
        ev = st.session_state.get(map_key)
        try:
            pts = ev["selection"]["points"]
        except (TypeError, KeyError):
            return
        for p in pts:
            idx = p.get("point_index")
            if idx is not None and 0 <= idx < len(cities):
                set_city(cities[idx])
                return
    return _cb


# -------------------------------------------------------------- page chrome
def page_title(title: str, sub: str = "") -> None:
    st.markdown(f"<h1 style='font-size:2.4rem;margin-bottom:.2rem'>{title}</h1>", unsafe_allow_html=True)
    if sub:
        st.markdown(f"<p class='note' style='max-width:46rem;font-size:1rem'>{sub}</p>", unsafe_allow_html=True)


def nav_link(path: str, label: str) -> None:
    """Link to another page; silently skipped when a page is run on its own (e.g. in tests)."""
    try:
        st.page_link(path, label=label)
    except Exception:
        pass


def date_range(df: pd.DataFrame, key: str, label: str = "Date range") -> tuple[pd.Timestamp, pd.Timestamp]:
    dmin, dmax = df["date"].min().date(), df["date"].max().date()
    rng = st.date_input(label, value=(dmin, dmax), min_value=dmin, max_value=dmax, key=key)
    if not (isinstance(rng, (tuple, list)) and len(rng) == 2):
        st.info("Pick both a start and an end date.")
        st.stop()
    return pd.Timestamp(rng[0]), pd.Timestamp(rng[1])
