"""Colours, CSS and the shared Plotly styling for the Heat Atlas look."""
from __future__ import annotations

import plotly.graph_objects as go

import os

MODE = os.environ.get("UHI_THEME", "dark").lower()
if MODE == "light":
    NAVY, MUTED, TEAL, PANEL, LINE, BG = "#10243E", "#5B6B7F", "#1F7A8C", "#FFFDF8", "#E4DDCF", "#F7F4EE"
    GRID, SOFT, BTN_TXT, MAPSTYLE = "#ECE6DA", "#EFEAE0", "#FFFFFF", "carto-positron"
    CITY_COLORS = {"Delhi": "#B8472A", "Bangalore": "#1F7A8C"}
else:  # dark: NAVY is the main text colour
    NAVY, MUTED, TEAL, PANEL, LINE, BG = "#E8EEF5", "#9AABBF", "#3CC3D4", "#101D2E", "#26384F", "#0A1320"
    GRID, SOFT, BTN_TXT, MAPSTYLE = "#1F2F45", "#16263A", "#0A1320", "carto-darkmatter"
    CITY_COLORS = {"Delhi": "#F0804F", "Bangalore": "#3CC3D4"}
BTN_HOVER = TEAL

# cool teal -> sand -> orange -> red: used for every temperature colour
HEAT_SCALE = [[0.0, "#2F7F93"], [0.25, "#8CC3C0"], [0.5, "#F3E6C8"], [0.75, "#EE9B4D"], [1.0, "#C2362B"]]
# diverging scale for urban-minus-rural differences (blue = urban cooler, red = urban warmer)
GAP_SCALE = [[0.0, "#2F7F93"], [0.5, "#F3E6C8"], [1.0, "#C2362B"]]

ZONE_DASH = {"Urban": "solid", "Rural": "dash"}
FONT = "DM Sans, Segoe UI, Helvetica, Arial, sans-serif"

CSS = f"""
<style>
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,700&family=DM+Sans:wght@400;500;700&display=swap');
.stApp, .stApp p, .stApp label, .stApp button, .stApp input, .stApp textarea, .stApp li, .stApp td, .stApp th, .stApp div[data-baseweb],
.stApp span:not([data-testid="stIconMaterial"]):not([class*="material"]) {{ font-family: {FONT}; }}
.stApp {{ background: {BG}; color: {NAVY}; }}
h1, h2, h3, .display {{ font-family: Fraunces, Georgia, 'Times New Roman', serif !important; color: {NAVY}; letter-spacing: -0.01em; }}
.block-container {{ max-width: 1320px; padding-top: 2.2rem; padding-bottom: 4rem; }}
header[data-testid="stHeader"] {{ background: {BG}ee; backdrop-filter: blur(6px); border-bottom: 1px solid {LINE}; }}
.stAppDeployButton, [data-testid="stMainMenu"], [data-testid="stStatusWidget"] {{ display: none; }}
[data-testid="stSidebar"], [data-testid="stSidebarCollapsedControl"] {{ display: none; }}
header a[data-testid="stTopNavLink"], header [data-testid="stTopNavLink"] {{ font-weight: 500; border-radius: 999px; }}
.display {{ font-size: clamp(2.3rem, 4.3vw, 3.7rem); line-height: 1.05; font-weight: 700; margin: .2rem 0 1rem 0; }}
.lede {{ font-size: 1.12rem; line-height: 1.6; color: {MUTED}; max-width: 34rem; }}
.chip {{ display:inline-flex; gap:.5rem; align-items:center; padding:.28rem .8rem; border:1px solid {LINE}; background:{PANEL};
        border-radius:999px; font-size:.82rem; color:{MUTED}; margin-bottom:1rem; }}
.chip .dot {{ width:.55rem; height:.55rem; border-radius:50%; background:#2E9E6B; display:inline-block; }}
.chip .dot.bad {{ background:#C2362B; }}
.statement {{ font-family: Fraunces, Georgia, serif; font-size: clamp(1.4rem, 2.3vw, 2.05rem); line-height: 1.25; font-weight: 500; margin: .2rem 0 .8rem 0; }}
.statement b {{ font-weight: 700; }}
.hot {{ color:{'#E5533F' if MODE=='dark' else '#C2362B'}; }} .cool {{ color:{TEAL}; }}
.note {{ font-size:.86rem; color:{MUTED}; line-height:1.5; }}
.mapnote {{ font-size:.8rem; color:{MUTED}; padding:.2rem .4rem 0 .4rem; }}
.signpost {{ border-top: 2px solid {NAVY}; padding-top:.7rem; }}
.signpost h4 {{ font-family: Fraunces, Georgia, serif; margin:.1rem 0 .3rem 0; font-size:1.25rem; }}
.signpost p {{ color:{MUTED}; font-size:.92rem; margin:0; }}
[data-testid="stVerticalBlockBorderWrapper"] {{ border-radius: 18px; border: 1px solid {LINE}; background: {PANEL};
        box-shadow: 0 1px 2px rgba(0,0,0,.15), 0 6px 18px rgba(0,0,0,.18); }}
.stButton > button[kind="primary"], .stDownloadButton > button, a[data-testid="stPageLink-NavLink"][href] {{ border-radius: 999px; }}
.stButton > button[kind="primary"] {{ background:{NAVY}; border-color:{NAVY}; color:{BTN_TXT}; }}
.stButton > button[kind="primary"]:hover {{ background:{TEAL}; border-color:{TEAL}; color:{BTN_TXT}; }}
.stTabs [data-baseweb="tab-list"] {{ gap: 1.2rem; border-bottom: 1px solid {LINE}; }}
.stTabs [aria-selected="true"] {{ color: {TEAL}; }}
@media (max-width: 900px) {{
  .block-container {{ padding-left:1rem; padding-right:1rem; }}
  .display {{ font-size: 2rem; overflow-wrap: anywhere; hyphens: auto; }}
  [data-testid="stHorizontalBlock"] {{ flex-wrap: wrap; }}
  [data-testid="stColumn"] {{ min-width: 100% !important; }}
}}
</style>
"""



THEME_EXTRA = ""


def style(fig: go.Figure, height: int = 400, title: str | None = None) -> go.Figure:
    """Apply the common look to a Plotly figure."""
    fig.update_layout(
        height=height,
        title=dict(text=title, x=0.0, xanchor="left", font=dict(size=15, color=NAVY)) if title else None,
        font=dict(family=FONT, color=NAVY, size=13),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=8, r=8, t=48 if title else 16, b=8),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1, title_text=""),
        hoverlabel=dict(bgcolor=PANEL, font=dict(size=13, family=FONT, color=NAVY), bordercolor=LINE),
    )
    fig.update_xaxes(gridcolor=GRID, zerolinecolor=LINE, linecolor=LINE)
    fig.update_yaxes(gridcolor=GRID, zerolinecolor=LINE, linecolor=LINE)
    return fig
