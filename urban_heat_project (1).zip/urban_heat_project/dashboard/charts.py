"""Plotly figure builders. Each function takes plain DataFrames and returns a figure."""
from __future__ import annotations

import os

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from . import theme as T
from .analysis import MONTHS, VARIABLES, city_centre, fmt

# "carto-positron"/"carto-darkmatter" need internet for map tiles. For an offline demo set UHI_MAP_STYLE=white-bg (markers only).
MAP_STYLE = os.environ.get("UHI_MAP_STYLE", T.MAPSTYLE)
if MAP_STYLE in ("offline", "white-bg"):  # no internet: plain background in the theme colour
    MAP_STYLE = {"version": 8, "sources": {}, "layers": [{"id": "bg", "type": "background", "paint": {"background-color": T.PANEL}}]}
MONTH_START_DOY = [1, 32, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335]


def _date(x) -> str:
    return pd.Timestamp(x).strftime("%d %b %Y")


# ------------------------------------------------------------------ map
def city_map(summary: pd.DataFrame, var: str, stat: str, selected: str | None, vmin: float, vmax: float, height: int = 470) -> go.Figure:
    """City markers on a basemap. Position = approximate city-centre reference point,
    colour = the chosen statistic of the chosen variable in the current selection."""
    v = VARIABLES[var]
    s = summary.set_index("city")
    cities = [c for c in s.index if city_centre(c)]
    lat = [city_centre(c)[0] for c in cities]
    lon = [city_centre(c)[1] for c in cities]
    vals, texts, labels = [], [], []
    for c in cities:
        r = s.loc[c]
        val = r.get(stat, np.nan)
        vals.append(val)
        labels.append(c if pd.isna(val) else f"{c}<br>{fmt(val, v['unit'])}")
        if r["n_valid"] == 0 or pd.isna(val):
            texts.append(f"<b>{c}</b><br>No valid {v['short']} observations in this selection")
            continue
        lines = [f"<b>{c}</b>", f"{ {'mean': 'Average', 'max': v['hi'] + ' observation', 'min': v['lo'] + ' observation'}[stat] }: <b>{fmt(val, v['unit'])}</b>"]
        if stat in ("max", "min"):
            lines.append(f"Measured: {_date(r[stat + '_date'])} ({r[stat + '_zone']} area)")
        lines.append(f"Latest day ({_date(r['latest_date'])}): {fmt(r['latest'], v['unit'])}")
        lines.append(f"{int(r['n_valid']):,} valid of {int(r['n_total']):,} records")
        texts.append("<br>".join(lines))

    fig = go.Figure()
    # halo behind the selected city
    if selected in cities:
        i = cities.index(selected)
        fig.add_trace(go.Scattermap(lat=[lat[i]], lon=[lon[i]], mode="markers", hoverinfo="skip", showlegend=False,
                                    marker=dict(size=62, color=T.NAVY, opacity=0.28)))
    valid = [x for x in vals if not pd.isna(x)]
    fig.add_trace(go.Scattermap(
        lat=lat, lon=lon, mode="markers", hovertext=texts, hoverinfo="text", name="",
        marker=dict(size=40, color=[x if not pd.isna(x) else np.nan for x in vals], colorscale=T.HEAT_SCALE, cmin=vmin, cmax=vmax,
                    showscale=bool(valid), opacity=0.95,
                    colorbar=dict(title=dict(text=f"{v['short']} ({v['unit']})", side="right"), thickness=12, len=0.55, x=0.99,
                                  bgcolor="rgba(0,0,0,0)", outlinewidth=0)),
        selected=dict(marker=dict(opacity=0.95)), unselected=dict(marker=dict(opacity=0.95)),
    ))
    fig.add_trace(go.Scattermap(lat=[x + 2.3 for x in lat], lon=lon, mode="text", text=labels, hoverinfo="skip", showlegend=False,
                                textfont=dict(size=14, color=T.NAVY if T.MODE == "dark" else "#10243E", family=T.FONT)))
    missing = [i for i, x in enumerate(vals) if pd.isna(x)]
    if missing:
        fig.add_trace(go.Scattermap(lat=[lat[i] for i in missing], lon=[lon[i] for i in missing], mode="markers", name="",
                                    hovertext=[texts[i] for i in missing], hoverinfo="text", showlegend=False,
                                    marker=dict(size=34, color="#B9B4A8")))
    fig.update_layout(map=dict(style=MAP_STYLE, center=dict(lat=21.0, lon=79.0), zoom=3.45), showlegend=False,
                      height=height, margin=dict(l=0, r=0, t=0, b=0), paper_bgcolor="rgba(0,0,0,0)", clickmode="event+select")
    return fig


# --------------------------------------------------------- stripes / calendar
def stripes(dates, rows: dict[str, list], vmin: float, vmax: float, unit: str = "°C", height: int = 150) -> go.Figure:
    """'Warming stripes': one coloured bar per day, one row per zone."""
    labels = list(rows)
    fig = go.Figure(go.Heatmap(
        z=[rows[k] for k in labels], x=list(dates), y=labels, colorscale=T.HEAT_SCALE, zmin=vmin, zmax=vmax,
        colorbar=dict(title=dict(text=unit, side="top"), thickness=10, len=0.9, outlinewidth=0),
        hovertemplate="%{y} · %{x|%d %b %Y}<br><b>%{z:.1f} " + unit + "</b><extra></extra>", ygap=3,
    ))
    fig.update_xaxes(showgrid=False, ticks="outside", tickformat="%Y", dtick="M12", tick0="2020-01-01")
    fig.update_yaxes(showgrid=False, autorange="reversed")
    return T.style(fig, height)


def heat_calendar(df: pd.DataFrame, var: str, vmin: float, vmax: float, title: str, height: int = 300) -> go.Figure:
    """One row per year, one column per day of year."""
    v = VARIABLES[var]
    d = df.groupby("date")[var].mean().reset_index()
    d["year"], d["doy"] = d["date"].dt.year, d["date"].dt.dayofyear
    z = d.pivot(index="year", columns="doy", values=var).reindex(columns=range(1, 367))
    txt = d.assign(t=d["date"].dt.strftime("%d %b %Y")).pivot(index="year", columns="doy", values="t").reindex(columns=range(1, 367))
    fig = go.Figure(go.Heatmap(
        z=z.values, x=z.columns, y=[str(y) for y in z.index], customdata=txt.values, colorscale=T.HEAT_SCALE, zmin=vmin, zmax=vmax,
        hovertemplate="%{customdata}<br><b>%{z:.1f} " + v["unit"] + "</b><extra></extra>", xgap=0, ygap=2,
        colorbar=dict(title=dict(text=v["unit"], side="top"), thickness=10, outlinewidth=0),
    ))
    fig.update_xaxes(tickmode="array", tickvals=MONTH_START_DOY, ticktext=MONTHS, showgrid=False)
    fig.update_yaxes(type="category", autorange="reversed", showgrid=False)
    return T.style(fig, height, title)


# ------------------------------------------------------------------ trends
def trend_chart(series: pd.DataFrame, var: str, smooth_days: int, title: str, height: int = 360) -> go.Figure:
    """`series` has columns date, city, zone, <var>. Raw daily values are drawn faintly when smoothing is on."""
    v = VARIABLES[var]
    fig = go.Figure()
    for (city, zone), g in series.groupby(["city", "zone"]):
        g = g.sort_values("date")
        col = T.CITY_COLORS.get(city, T.TEAL)
        name = f"{city} {zone}"
        y = g[var]
        if smooth_days > 1:
            fig.add_trace(go.Scatter(x=g["date"], y=y, mode="lines", line=dict(color=col, width=0.8), opacity=0.22, hoverinfo="skip", showlegend=False))
            y = g.set_index("date")[var].rolling(f"{smooth_days}D", min_periods=max(2, smooth_days // 3)).mean().values
        fig.add_trace(go.Scatter(
            x=g["date"], y=y, name=name, mode="lines", line=dict(color=col, width=2.2, dash=T.ZONE_DASH.get(zone, "solid")),
            hovertemplate=f"<b>{name}</b><br>%{{x|%d %b %Y}}<br>%{{y:.1f}} {v['unit']}<extra></extra>"))
    fig.update_yaxes(title=f"{v['short']} ({v['unit']})")
    fig.update_xaxes(title="")
    return T.style(fig, height, title)


def year_clock(profile: pd.DataFrame, var: str, title: str, height: int = 400) -> go.Figure:
    """Radial 'clock' of the average year: January at the top, months clockwise."""
    v = VARIABLES[var]
    fig = go.Figure()
    for (city, zone), g in profile.groupby(["city", "zone"]):
        g = g.sort_values("month")
        name = f"{city} {zone}"
        fig.add_trace(go.Scatterpolar(
            r=list(g[var]) + [g[var].iloc[0]], theta=list(g["Month"]) + [g["Month"].iloc[0]], name=name, mode="lines+markers",
            line=dict(color=T.CITY_COLORS.get(city, T.TEAL), width=2.4, dash=T.ZONE_DASH.get(zone, "solid")), marker=dict(size=5),
            hovertemplate=f"<b>{name}</b><br>%{{theta}}: %{{r:.1f}} {v['unit']}<extra></extra>"))
    fig.update_layout(polar=dict(bgcolor="rgba(0,0,0,0)", angularaxis=dict(direction="clockwise", rotation=90, categoryarray=MONTHS, gridcolor=T.GRID),
                                 radialaxis=dict(gridcolor=T.GRID, angle=90, tickfont=dict(size=10))))
    return T.style(fig, height, f"{title} ({v['unit']})")


# ------------------------------------------------------------ urban vs rural
def dumbbell(site_means: pd.DataFrame, var: str, title: str, height: int = 260) -> go.Figure:
    """Rural -> urban mean for each city. `site_means` columns: city, zone, Mean."""
    v = VARIABLES[var]
    fig = go.Figure()
    p = site_means.pivot(index="city", columns="zone", values="Mean")
    for city in p.index:
        r, u = p.loc[city].get("Rural", np.nan), p.loc[city].get("Urban", np.nan)
        col = T.CITY_COLORS.get(city, T.TEAL)
        if not (np.isnan(r) or np.isnan(u)):
            fig.add_trace(go.Scatter(x=[r, u], y=[city, city], mode="lines", line=dict(color=col, width=5), opacity=0.5, hoverinfo="skip", showlegend=False))
        for zone, val, sym in (("Rural", r, "circle-open"), ("Urban", u, "circle")):
            if np.isnan(val):
                continue
            fig.add_trace(go.Scatter(x=[val], y=[city], mode="markers", name=zone, legendgroup=zone, showlegend=city == p.index[0],
                                     marker=dict(size=17, color=col, symbol=sym, line=dict(width=3, color=col)),
                                     hovertemplate=f"<b>{city} {zone}</b><br>Mean {v['short']}: %{{x:.2f}} {v['unit']}<extra></extra>"))
    fig.update_xaxes(title=f"Mean {v['short']} ({v['unit']})")
    return T.style(fig, height, title)


def gap_by_month(gap: pd.DataFrame, var: str, title: str, height: int = 320) -> go.Figure:
    v = VARIABLES[var]
    g = gap.assign(month=gap["date"].dt.month).groupby(["city", "month"])["gap"].mean().reset_index()
    fig = go.Figure()
    for city, d in g.groupby("city"):
        fig.add_trace(go.Scatter(x=[MONTHS[m - 1] for m in d["month"]], y=d["gap"], name=city, mode="lines+markers",
                                 line=dict(color=T.CITY_COLORS.get(city, T.TEAL), width=2.6),
                                 hovertemplate=f"<b>{city}</b><br>%{{x}}: %{{y:+.2f}} {v['unit']}<extra></extra>"))
    fig.add_hline(y=0, line_color=T.NAVY, line_width=1)
    fig.update_yaxes(title=f"Urban − rural {v['short']} ({v['unit']})", zeroline=False)
    fig.update_xaxes(categoryorder="array", categoryarray=MONTHS)
    return T.style(fig, height, title)


# ---------------------------------------------------------------- ML charts
def model_scoreboard(table: pd.DataFrame, selected: str, height: int = 420) -> go.Figure:
    """`table` columns: model, RMSE, R2, kind ('model' | 'baseline'). Sorted by RMSE."""
    t = table.sort_values("RMSE", ascending=False)
    colors = [T.TEAL if m == selected else ("#B9B4A8" if k == "baseline" else "#8CC3C0") for m, k in zip(t["model"], t["kind"])]
    fig = make_subplots(rows=1, cols=2, shared_yaxes=True, horizontal_spacing=0.04, subplot_titles=("RMSE (°C) · lower is better", "R² · higher is better"))
    fig.add_trace(go.Bar(x=t["RMSE"], y=t["model"], orientation="h", marker_color=colors, texttemplate="%{x:.2f}", textposition="outside", cliponaxis=False,
                         hovertemplate="%{y}<br>RMSE %{x:.3f} °C<extra></extra>", showlegend=False), 1, 1)
    fig.add_trace(go.Bar(x=t["R2"], y=t["model"], orientation="h", marker_color=colors, texttemplate="%{x:.2f}", textposition="outside", cliponaxis=False,
                         hovertemplate="%{y}<br>R² %{x:.3f}<extra></extra>", showlegend=False), 1, 2)
    fig.update_xaxes(range=[0, float(t["RMSE"].max()) * 1.18], row=1, col=1)
    fig.update_xaxes(zeroline=True, range=[min(0.0, float(t["R2"].min())) - 0.12, float(t["R2"].max()) + 0.12], row=1, col=2)
    fig.update_layout(annotations=[a.update(font=dict(size=13, color=T.NAVY)) or a for a in fig.layout.annotations])
    return T.style(fig, height)


def importance_bar(imp: pd.DataFrame, height: int = 340) -> go.Figure:
    d = imp.sort_values("importance_rmse_increase")
    fig = go.Figure(go.Bar(x=d["importance_rmse_increase"], y=d["feature"], orientation="h", error_x=dict(array=d["std"]), marker_color=T.TEAL,
                           hovertemplate="%{y}<br>RMSE rises by %{x:.3f} °C when shuffled<extra></extra>"))
    fig.update_xaxes(title="Increase in test RMSE (°C) when the feature is shuffled")
    return T.style(fig, height, "Feature importance (best model)")


def obs_vs_pred(pred: pd.DataFrame, model: str, height: int = 400) -> go.Figure:
    fig = go.Figure()
    for city, g in pred.groupby("city"):
        fig.add_trace(go.Scatter(x=g["actual"], y=g[model], mode="markers", name=city, opacity=0.55,
                                 marker=dict(size=5, color=T.CITY_COLORS.get(city, T.TEAL)),
                                 hovertemplate=f"<b>{city}</b><br>Observed %{{x:.1f}} °C<br>Predicted %{{y:.1f}} °C<extra></extra>"))
    lo, hi = float(pred["actual"].min()), float(pred["actual"].max())
    fig.add_trace(go.Scatter(x=[lo, hi], y=[lo, hi], mode="lines", line=dict(color=T.NAVY, dash="dash", width=1), name="Perfect prediction", hoverinfo="skip"))
    fig.update_xaxes(title="Observed LST (°C)")
    fig.update_yaxes(title="Predicted LST (°C)")
    return T.style(fig, height, f"{model}: actual vs predicted")
