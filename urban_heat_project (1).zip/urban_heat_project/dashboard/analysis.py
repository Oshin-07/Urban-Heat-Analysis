"""Pure pandas helpers for the dashboard (no Streamlit imports, so they are easy to test)."""
from __future__ import annotations

import numpy as np
import pandas as pd

from uhi import config as C

SEASONS = ["Winter", "Summer", "Monsoon", "Post-monsoon"]
MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

# column -> display information (units come from the project README / cleaning code)
VARIABLES = {
    "lst_c": {"label": "Land surface temperature", "short": "LST", "unit": "°C", "hi": "Hottest", "lo": "Coolest"},
    "no2_umol_m2": {"label": "NO₂ column density", "short": "NO₂", "unit": "µmol/m²", "hi": "Highest", "lo": "Lowest"},
    "wind_speed_file": {"label": "Wind speed (as supplied)", "short": "Wind speed", "unit": "m/s", "hi": "Highest", "lo": "Lowest"},
}
STATS = {"Average": "mean", "Highest day": "max", "Lowest day": "min"}


def filter_data(df, cities=None, zones=None, start=None, end=None, seasons=None, hide_outliers=True) -> pd.DataFrame:
    """Apply the user's filters. Flagged LST outliers are blanked (NaN), never deleted,
    so NO₂ and wind for those days stay available and gaps remain visible."""
    mask = pd.Series(True, index=df.index)
    if cities is not None:
        mask &= df["city"].isin(cities)
    if zones is not None:
        mask &= df["zone"].isin(zones)
    if start is not None:
        mask &= df["date"] >= pd.Timestamp(start)
    if end is not None:
        mask &= df["date"] <= pd.Timestamp(end)
    if seasons is not None:
        mask &= df["season"].isin(seasons)
    out = df.loc[mask].copy()
    if hide_outliers:
        out.loc[out["lst_outlier"], "lst_c"] = np.nan
    return out


def city_summary(df: pd.DataFrame, var: str) -> pd.DataFrame:
    """One row per city: mean, extreme observations (with date and zone), latest value, coverage."""
    rows = []
    for city, g in df.groupby("city"):
        s = g[["date", "zone", var]].dropna()
        row = {"city": city, "n_total": len(g), "n_valid": len(s)}
        if s.empty:
            rows.append({**row, "mean": np.nan, "max": np.nan, "min": np.nan, "latest": np.nan})
            continue
        imax, imin = s[var].idxmax(), s[var].idxmin()
        last_date = s["date"].max()
        rows.append({
            **row, "mean": s[var].mean(),
            "max": s.loc[imax, var], "max_date": s.loc[imax, "date"], "max_zone": s.loc[imax, "zone"],
            "min": s.loc[imin, var], "min_date": s.loc[imin, "date"], "min_zone": s.loc[imin, "zone"],
            "latest": s.loc[s["date"] == last_date, var].mean(), "latest_date": last_date,
        })
    return pd.DataFrame(rows)


def site_stats(df: pd.DataFrame, var: str) -> pd.DataFrame:
    """Mean / max / min / std and data coverage for every city x zone."""
    g = df.groupby(["city", "zone"])[var]
    out = pd.DataFrame({
        "Mean": g.mean(), "Max": g.max(), "Min": g.min(), "Std dev": g.std(),
        "Valid days": g.count(), "Blank / flagged": g.apply(lambda s: int(s.isna().sum())),
    })
    return out.reset_index()


def urban_rural_gap(df: pd.DataFrame, var: str = "lst_c") -> pd.DataFrame:
    """Urban minus rural value per date and city (only dates where both exist)."""
    w = df.pivot_table(index=["date", "city"], columns="zone", values=var)
    if not {"Urban", "Rural"}.issubset(w.columns):
        return pd.DataFrame(columns=["date", "city", "gap"])
    w = w.dropna(subset=["Urban", "Rural"])
    return (w["Urban"] - w["Rural"]).rename("gap").reset_index()


def monthly_profile(df: pd.DataFrame, var: str) -> pd.DataFrame:
    """Mean by site and calendar month (the 'year clock' data)."""
    p = df.groupby(["city", "zone", "month"])[var].mean().reset_index()
    p["Month"] = p["month"].map(lambda m: MONTHS[m - 1])
    return p


def resample_series(df: pd.DataFrame, var: str, freq: str) -> pd.DataFrame:
    """Mean per site for D / W / MS (daily, weekly, monthly)."""
    p = df.pivot_table(index="date", columns=["city", "zone"], values=var)
    if freq != "D":
        p = p.resample(freq).mean()
    out = p.stack(["city", "zone"], future_stack=True).rename(var).reset_index()
    return out


def fmt(value, unit: str = "", digits: int = 1) -> str:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return "not available"
    return f"{value:,.{digits}f} {unit}".strip()


def gap_sentence(city: str, urban_mean: float, rural_mean: float) -> str:
    """Plain-language headline about the urban-rural difference (computed, never hard-coded)."""
    if np.isnan(urban_mean) or np.isnan(rural_mean):
        return f"There are not enough urban and rural observations for {city} in this selection."
    d = urban_mean - rural_mean
    word = "warmer" if d > 0 else "cooler"
    return (
        f"<b>{city}</b>: the urban area averages <b>{urban_mean:.1f} °C</b>, the rural area "
        f"<b>{rural_mean:.1f} °C</b> — urban is on average <b class='{'hot' if d > 0 else 'cool'}'>{abs(d):.2f} °C {word}</b>."
    )


def city_centre(city: str) -> tuple[float, float] | None:
    return C.CITY_CENTRES.get(city)
