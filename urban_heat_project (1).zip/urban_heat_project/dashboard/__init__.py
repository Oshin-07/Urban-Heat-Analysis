"""UI layer of the Urban Heat Analysis dashboard (the data/ML logic lives in `uhi/`)."""
