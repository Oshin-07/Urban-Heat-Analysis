import streamlit as st

from dashboard import common as cm
from uhi import config as C

df = cm.need_data()
cm.page_title("About")
a, b = st.columns(2, gap="large")
with a:
    with st.container(border=True):
        st.markdown("### Project")
        st.markdown("Urban Heat Analysis Across Indian Cities. The project compares land surface temperature (LST) of urban and rural areas of "
                    f"{' and '.join(C.CITIES)} and predicts LST with machine learning.")
    with st.container(border=True):
        st.markdown("### Data")
        st.markdown(f"Daily LST (°C), NO₂ (µmol/m²) and wind (m/s), {df['date'].min():%d %b %Y} – {df['date'].max():%d %b %Y}, "
                    f"{len(df):,} rows. Files: `{'`, `'.join(C.RAW_FILES.values())}`.")
with b:
    with st.container(border=True):
        st.markdown("### Method")
        st.markdown("Data cleaning, exploratory analysis, then six regression models compared: Linear Regression, KNN, Decision Tree, Random Forest, "
                    "SVR and Gradient Boosting. Each is tuned with GridSearchCV (5-fold) and evaluated with MAE, MSE, RMSE and R² on a 20% test split "
                    "and on the unseen year 2025.")
    with st.container(border=True):
        st.markdown("### Limitations")
        st.markdown("Only two cities. Map markers are approximate city-centre points, not satellite data.")
