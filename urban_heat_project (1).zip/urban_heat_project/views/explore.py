import streamlit as st

from dashboard import analysis as A
from dashboard import charts as ch
from dashboard import common as cm
from uhi import config as C

df = cm.need_data()
cities = [c for c in C.CITIES if c in set(df["city"])]
cm.page_title("Explore Map")

map_col, ctl_col = st.columns([7, 3], gap="large")
with ctl_col:
    with st.container(border=True):
        sel = cm.city_picker(cities, "pick_explore", "City")
        var = st.segmented_control("Variable", list(A.VARIABLES), default="lst_c", key="ex_var",
                                   format_func=lambda k: A.VARIABLES[k]["short"]) or "lst_c"
        stat_label = st.segmented_control("Map shows", list(A.STATS), default="Average", key="ex_stat") or "Average"
        start, end = cm.date_range(df, "ex_dates")
        zones = st.multiselect("Zones", ["Urban", "Rural"], default=["Urban", "Rural"], key="ex_zones")
        seasons = st.multiselect("Seasons", A.SEASONS, default=A.SEASONS, key="ex_seasons")
        hide = st.toggle("Hide flagged LST values", value=True, key="ex_hide")

if not zones or not seasons:
    st.warning("Select at least one zone and one season.")
    st.stop()
if start > end:
    st.warning("The start date is after the end date.")
    st.stop()
filtered = A.filter_data(df, zones=zones, start=start, end=end, seasons=seasons, hide_outliers=hide)
if filtered.empty or filtered[var].dropna().empty:
    st.info("No data for these filters.")
    st.stop()

meta = A.VARIABLES[var]
ref = A.filter_data(df, hide_outliers=True)[var].dropna()
summary = A.city_summary(filtered, var)
order = [c for c in summary["city"] if C.CITY_CENTRES.get(c)]
if sel not in set(summary["city"]):
    st.info(f"No data for {sel}.")
    st.stop()
sel_df = filtered[filtered["city"] == sel]

with map_col:
    with st.container(border=True):
        st.plotly_chart(ch.city_map(summary, var, A.STATS[stat_label], sel, ref.quantile(0.02), ref.quantile(0.98), height=480), key="map_explore",
                        on_select=cm.map_click_handler("map_explore", order), selection_mode="points",
                        config={"displayModeBar": False}, width="stretch")
    with st.container(border=True):
        smooth_label = st.segmented_control("View", ["Daily", "7-day", "30-day"], default="30-day", key="ex_smooth") or "30-day"
        smooth = {"Daily": 1, "7-day": 7, "30-day": 30}[smooth_label]
        st.plotly_chart(ch.trend_chart(sel_df[["date", "city", "zone", var]], var, smooth, f"{meta['label']} in {sel}"),
                        config={"displayModeBar": False}, width="stretch")

with ctl_col:
    with st.container(border=True):
        st.markdown(f"**{sel}**")
        ss = A.site_stats(sel_df, var)[["zone", "Mean", "Max", "Min"]].rename(columns={"zone": "Zone"})
        st.dataframe(ss, hide_index=True, width="stretch", column_config={c: st.column_config.NumberColumn(c, format="%.1f") for c in ("Mean", "Max", "Min")})

t1, t2, t3, t4 = st.tabs(["Year clock", "Heat calendar", "NO₂ and wind", "Data"])
with t1:
    a, b = st.columns(2, gap="large")
    a.plotly_chart(ch.year_clock(A.monthly_profile(sel_df, var), var, f"{meta['short']} by month"), config={"displayModeBar": False}, width="stretch")
    gap = A.urban_rural_gap(sel_df, var)
    if not gap.empty:
        b.plotly_chart(ch.gap_by_month(gap, var, "Urban − rural by month"), config={"displayModeBar": False}, width="stretch")
with t2:
    for z in sorted(sel_df["zone"].unique()):
        st.plotly_chart(ch.heat_calendar(sel_df[sel_df["zone"] == z], var, ref.quantile(0.02), ref.quantile(0.98), f"{sel} {z}", 230),
                        config={"displayModeBar": False}, width="stretch")
with t3:
    a, b = st.columns(2, gap="large")
    for col, v2 in zip((a, b), ("no2_umol_m2", "wind_speed_file")):
        m2 = A.VARIABLES[v2]
        col.plotly_chart(ch.trend_chart(sel_df[["date", "city", "zone", v2]], v2, 30, f"{m2['label']} ({m2['unit']})", 320), config={"displayModeBar": False}, width="stretch")
with t4:
    cols = ["date", "city", "zone", "season", "lst_c", "lst_outlier", "no2_umol_m2", "wind_u", "wind_v", "wind_speed_file"]
    d1, d2 = st.columns(2)
    d1.download_button(f"⬇ Download {sel} (CSV)", sel_df[cols].to_csv(index=False).encode("utf-8"), f"urban_heat_{sel.lower()}.csv", "text/csv")
    d2.download_button("⬇ Download all cities (CSV)", filtered[cols].to_csv(index=False).encode("utf-8"), "urban_heat_all_cities.csv", "text/csv")
    with st.expander("Show table", expanded=False):
        st.dataframe(sel_df[cols].head(1000), hide_index=True, width="stretch", height=360)
