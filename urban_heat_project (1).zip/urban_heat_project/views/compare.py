import plotly.graph_objects as go
import streamlit as st

from dashboard import analysis as A
from dashboard import charts as ch
from dashboard import common as cm
from dashboard import theme as T
from uhi import config as C

df = cm.need_data()
cities = [c for c in C.CITIES if c in set(df["city"])]
cm.page_title("Compare Cities")

with st.container(border=True):
    c1, c2, c3, c4 = st.columns([2, 2, 3, 3])
    chosen = c1.multiselect("Cities", cities, default=cities, key="cmp_cities")
    zones = c2.multiselect("Zones", ["Urban", "Rural"], default=["Urban", "Rural"], key="cmp_zones")
    with c3:
        start, end = cm.date_range(df, "cmp_dates")
    var = c4.segmented_control("Variable", list(A.VARIABLES), default="lst_c", key="cmp_var", format_func=lambda k: A.VARIABLES[k]["short"]) or "lst_c"

if len(chosen) < 2:
    st.info("Select at least two cities to compare.")
    st.stop()
if not zones or start > end:
    st.warning("Select at least one zone and a valid date range.")
    st.stop()
d = A.filter_data(df, cities=chosen, zones=zones, start=start, end=end, hide_outliers=True)
if d[var].dropna().empty:
    st.info("No data for these filters.")
    st.stop()
meta = A.VARIABLES[var]

a, b = st.columns(2, gap="large")
with a:
    with st.container(border=True):
        st.plotly_chart(ch.dumbbell(A.site_stats(d, var), var, f"Average {meta['short']}: rural vs urban", 300), config={"displayModeBar": False}, width="stretch")
with b:
    with st.container(border=True):
        seas = d.groupby(["city", "season"])[var].mean().reset_index()
        fig = go.Figure()
        for city, g in seas.groupby("city"):
            g = g.set_index("season").reindex(A.SEASONS)
            fig.add_trace(go.Bar(x=A.SEASONS, y=g[var], name=city, marker_color=T.CITY_COLORS.get(city, T.TEAL)))
        fig.update_layout(barmode="group")
        fig.update_yaxes(title=f"{meta['short']} ({meta['unit']})")
        st.plotly_chart(T.style(fig, 300, "Average by season"), config={"displayModeBar": False}, width="stretch")

with st.container(border=True):
    ser = A.resample_series(d, var, "MS").dropna(subset=[var])
    st.plotly_chart(ch.trend_chart(ser, var, 1, f"{meta['label']}: monthly average", 380), config={"displayModeBar": False}, width="stretch")

with st.container(border=True):
    st.dataframe(A.site_stats(d, var).rename(columns={"city": "City", "zone": "Zone"}), hide_index=True, width="stretch",
                 column_config={c: st.column_config.NumberColumn(c, format="%.2f") for c in ("Mean", "Max", "Min", "Std dev")})
    st.download_button("⬇ Download (CSV)", d[["date", "city", "zone", "season", var]].to_csv(index=False).encode("utf-8"), "urban_heat_comparison.csv", "text/csv")
