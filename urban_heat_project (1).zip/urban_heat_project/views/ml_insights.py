import joblib
import pandas as pd
import streamlit as st

from dashboard import analysis as A
from dashboard import charts as ch
from dashboard import common as cm
from uhi import config as C

df = cm.need_data()
res, meta = cm.load_csv("model_results.csv"), cm.load_json("best_model.json")
cm.page_title("ML Insights")
if res is None or meta is None:
    st.error("Model results not found. Run `python 03_train_models.py` in the project folder, then refresh.")
    st.stop()

best = meta["model_name"]
m = meta["metrics"]
st.markdown(f"<div class='statement'>Best model: <b>{best}</b> — R² {m['R2']:.2f}, average error {m['MAE']:.1f} °C.</div>", unsafe_allow_html=True)

tab1, tab2, tab3, tab4 = st.tabs(["Model comparison", "Accuracy", "Important features", "Predict LST"])

with tab1:
    with st.container(border=True):
        t = res.assign(kind="model", model=res["Model"])
        st.plotly_chart(ch.model_scoreboard(t[["model", "RMSE", "R2", "kind"]], best, 380), config={"displayModeBar": False}, width="stretch")
    show = res[["Model", "CV R2", "MAE", "MSE", "RMSE", "R2", "RMSE 2025", "R2 2025"]]
    st.dataframe(show.sort_values("CV R2", ascending=False), hide_index=True, width="stretch",
                 column_config={c: st.column_config.NumberColumn(format="%.3f") for c in show.columns if c != "Model"})
    with st.expander("Best parameters (GridSearchCV)"):
        st.dataframe(res[["Model", "Best Parameters"]], hide_index=True, width="stretch")

with tab2:
    pred = cm.load_csv("predictions.csv")
    if pred is None:
        st.warning("predictions.csv not found.")
    else:
        models = [c for c in pred.columns if c not in ("city", "zone", "Actual")]
        pick = st.selectbox("Model", models, index=models.index(best) if best in models else 0)
        a1, a2 = st.columns(2, gap="large")
        with a1:
            with st.container(border=True):
                st.plotly_chart(ch.obs_vs_pred(pred.rename(columns={"Actual": "actual"}), pick), config={"displayModeBar": False}, width="stretch")
        with a2:
            with st.container(border=True):
                import plotly.express as px
                r = pred.assign(residual=pred["Actual"] - pred[pick])
                fig = px.histogram(r, x="residual", color="city", color_discrete_map=ch.T.CITY_COLORS, nbins=50, barmode="overlay", opacity=0.7,
                                   labels={"residual": "Actual − predicted (°C)"})
                st.plotly_chart(ch.T.style(fig, 400, f"{pick}: residuals"), config={"displayModeBar": False}, width="stretch")

with tab3:
    imp = cm.load_csv("feature_importance.csv")
    if imp is None:
        st.warning("feature_importance.csv not found.")
    else:
        with st.container(border=True):
            st.plotly_chart(ch.importance_bar(imp), config={"displayModeBar": False}, width="stretch")

with tab4:
    bundle = None
    p = C.MODEL_DIR / "best_model.joblib"
    if p.exists():
        bundle = joblib.load(p)
    if bundle is None:
        st.error("Trained model not found. Run `python 03_train_models.py`.")
        st.stop()
    u = A.filter_data(df, hide_outliers=True)
    with st.form("predict"):
        c1, c2, c3 = st.columns(3)
        city = c1.selectbox("City", C.CITIES)
        zone = c2.selectbox("Zone", C.ZONES)
        month_name = c3.selectbox("Month", A.MONTHS, index=4)
        r = u[u["city"] == city]
        n1, n2, n3 = st.columns(3)
        no2 = n1.number_input("NO₂ (µmol/m²)", float(r["no2_umol_m2"].min()), float(r["no2_umol_m2"].max()), float(r["no2_umol_m2"].median()), step=5.0)
        wu = n2.number_input("Wind u (m/s)", float(r["wind_u"].min()), float(r["wind_u"].max()), float(round(r["wind_u"].median(), 2)), step=0.1)
        wv = n3.number_input("Wind v (m/s)", float(r["wind_v"].min()), float(r["wind_v"].max()), float(round(r["wind_v"].median(), 2)), step=0.1)
        go_ = st.form_submit_button("Predict LST", type="primary")
    if go_:
        month = A.MONTHS.index(month_name) + 1
        row = pd.DataFrame([{"city": city, "zone": zone, "season": bundle["season_of_month"][month], "month": month,
                             "no2_umol_m2": no2, "wind_u": wu, "wind_v": wv}])
        for col, le in bundle["encoders"].items():
            row[col] = le.transform(row[col])
        row = row[bundle["columns"]]
        if bundle["scaler"] is not None:
            row = bundle["scaler"].transform(row)
        st.metric("Predicted LST (estimate)", f"{float(bundle['model'].predict(row)[0]):.1f} °C")
