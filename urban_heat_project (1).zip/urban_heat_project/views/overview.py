import numpy as np
import streamlit as st

from dashboard import analysis as A
from dashboard import charts as ch
from dashboard import common as cm
from uhi import config as C

df = cm.need_data()
cities = [c for c in C.CITIES if c in set(df["city"])]
base = A.filter_data(df, hide_outliers=True)
lo, hi = base["lst_c"].quantile(0.02), base["lst_c"].quantile(0.98)

left, right = st.columns([5, 6], gap="large")
with left:
    st.markdown("<h1 class='display'>Understanding Urban Heat Across Indian Cities</h1>", unsafe_allow_html=True)
    st.markdown(f"<p class='lede'>Daily land surface temperature of the urban and rural areas of {' and '.join(cities)}, "
                f"{df['date'].min():%Y}–{df['date'].max():%Y}.</p>", unsafe_allow_html=True)
    if st.button("Explore the Map →", type="primary"):
        try:
            st.switch_page("views/explore.py")
        except Exception:
            pass
with right:
    with st.container(border=True):
        summary = A.city_summary(base, "lst_c")
        order = [c for c in summary["city"] if C.CITY_CENTRES.get(c)]
        sel = cm.get_city(cities)
        st.plotly_chart(ch.city_map(summary, "lst_c", "mean", sel, lo, hi, height=430), key="map_overview",
                        on_select=cm.map_click_handler("map_overview", order), selection_mode="points",
                        config={"displayModeBar": False}, width="stretch")

sel = cm.city_picker(cities, "pick_overview", "Select a city", pills=True)
d = A.filter_data(df, cities=[sel], hide_outliers=True)
zm = d.groupby("zone")["lst_c"].mean()
st.markdown(f"<div class='statement'>{A.gap_sentence(sel, zm.get('Urban', np.nan), zm.get('Rural', np.nan))}</div>", unsafe_allow_html=True)
p = d.pivot_table(index="date", columns="zone", values="lst_c")
st.plotly_chart(ch.stripes(p.index, {z: p[z].tolist() for z in ("Urban", "Rural") if z in p}, lo, hi), config={"displayModeBar": False}, width="stretch")
st.caption("Each bar is one day.")
