"""Code from the class practicals, applied to the Urban Heat data.

Every function follows the steps taught in the practicals so it can be compared line by line with the notebooks:
  Practical 1  (Titanic)    : head/info/describe/isnull, histplot, corr heatmap, get_dummies, scaling
  Practical 3  (cardekho, bike) : LabelEncoder, train_test_split(0.20, 42), LinearRegression, MAE/MSE/RMSE/R2,
                                  actual-vs-predicted, residuals, coefficients, GridSearchCV
  Practical 4  (wine, diabetes) : StandardScaler, euclidean_distance, KNN written by hand, KNeighborsRegressor
Practical 2 (Find-S) needs yes/no categorical data, so it is not applicable to continuous temperature.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.neighbors import KNeighborsRegressor
from sklearn.preprocessing import LabelEncoder, MinMaxScaler, StandardScaler

FEATURES = ["city", "zone", "season", "month", "no2_umol_m2", "wind_u", "wind_v"]
TARGET = "lst_c"


# ---------------------------------------------------------------- Practical 1
def one_hot(df: pd.DataFrame) -> pd.DataFrame:
    """Practical 1: pd.get_dummies on the text columns."""
    return pd.get_dummies(df[["city", "zone", "no2_umol_m2", TARGET]], columns=["city", "zone"])


def feature_scaling(df: pd.DataFrame) -> pd.DataFrame:
    """Practical 1: StandardScaler on one column, MinMaxScaler on another."""
    out = df[["no2_umol_m2", TARGET]].copy()
    out["no2_umol_m2"] = StandardScaler().fit_transform(out[["no2_umol_m2"]])
    out[TARGET] = MinMaxScaler().fit_transform(out[[TARGET]])
    return out


# ---------------------------------------------------------------- Practical 3
def prepare_data(df: pd.DataFrame):
    """Practical 3a: LabelEncoder for text columns, then x = features, y = target.
    The 28 flagged LST outliers are left out."""
    data = df.loc[~df["lst_outlier"], FEATURES + [TARGET]].copy()
    le = LabelEncoder()
    for col in ("city", "zone", "season"):
        data[col] = le.fit_transform(data[col])
    x = data.drop(TARGET, axis=1)
    y = data[TARGET]
    return x, y


def split_data(x, y):
    """Practical 3 and 4: 80/20 split with random_state=42."""
    return train_test_split(x, y, test_size=0.20, random_state=42)


def regression_metrics(y_test, y_pred) -> dict:
    """Practical 3 and 4: MAE, MSE, RMSE and R2 Score."""
    mae = mean_absolute_error(y_test, y_pred)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)
    return {"MAE": mae, "MSE": mse, "RMSE": rmse, "R2 Score": r2}


def linear_regression(x_train, y_train, x_test, y_test):
    """Practical 3: LinearRegression -> fit -> predict -> metrics -> coefficients."""
    model = LinearRegression()
    model.fit(x_train, y_train)
    y_pred = model.predict(x_test)
    coef = pd.DataFrame({"Feature": x_train.columns, "Coefficient": model.coef_})
    return model, y_pred, regression_metrics(y_test, y_pred), coef.sort_values(by="Coefficient", ascending=False)


def grid_search_linear(x_train, y_train):
    """Practical 3a: GridSearchCV over the LinearRegression settings, cv=5, scoring='r2'."""
    param_grid = {"fit_intercept": [True, False], "copy_X": [True, False], "positive": [True, False]}
    grid = GridSearchCV(estimator=LinearRegression(), param_grid=param_grid, cv=5, scoring="r2")
    grid.fit(x_train, y_train)
    return grid


# ---------------------------------------------------------------- Practical 4
def scale_features(x_train, x_test):
    """Practical 4: StandardScaler. Fit on the training data only, then transform both."""
    scaler = StandardScaler()
    x_train = scaler.fit_transform(x_train)
    x_test = scaler.transform(x_test)
    return x_train, x_test


def euclidean_distance(x1, x2):
    return np.sqrt(np.sum((x1 - x2) ** 2))


class KNNRegressor:
    """k-Nearest Neighbours written by hand (Practical 4, regression version: mean of the k nearest targets).
    The only change from the notebook is that distances to all training points are computed in one numpy call
    so that it finishes in seconds on 7,000 rows."""

    def __init__(self, k=3):
        self.k = k

    def fit(self, X, y):
        self.X_train = np.array(X)
        self.y_train = np.array(y)

    def predict(self, X):
        X = np.array(X)
        predictions = [self._predict(x) for x in X]
        return np.array(predictions)

    def _predict(self, x):
        distances = np.sqrt(np.sum((self.X_train - x) ** 2, axis=1))
        k_indices = np.argsort(distances)[: self.k]
        k_nearest_values = [self.y_train[i] for i in k_indices]
        return np.mean(k_nearest_values)


def knn_sklearn(x_train_scaled, y_train, x_test_scaled, k=5):
    """Practical 4 (diabetes notebook): KNeighborsRegressor(n_neighbors=5)."""
    knn = KNeighborsRegressor(n_neighbors=k)
    knn.fit(x_train_scaled, y_train)
    return knn, knn.predict(x_test_scaled)
