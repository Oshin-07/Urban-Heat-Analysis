"""Feature construction shared by training AND the dashboard (single source of truth)."""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler

CATEGORICAL = ["city", "zone"]
FEATURE_SETS: dict[str, list[str]] = {
    # environment + season + site
    "full": ["no2_umol_m2", "wind_u", "wind_v", "wind_speed", "doy_sin", "doy_cos"] + CATEGORICAL,
    # no calendar information: how much do NO2 + wind alone explain?
    "environment_only": ["no2_umol_m2", "wind_u", "wind_v", "wind_speed"] + CATEGORICAL,
    # only season + site
    "calendar_only": ["doy_sin", "doy_cos"] + CATEGORICAL,
}
TARGET = "lst_c"


def make_features(df: pd.DataFrame, feature_set: str = "full") -> pd.DataFrame:
    """Build model inputs from raw columns (date, city, zone, no2_umol_m2, wind_u, wind_v).

    Day-of-year is encoded as sine/cosine so that 31 Dec and 1 Jan are neighbours.
    Wind speed is recomputed as sqrt(u^2+v^2) so the dashboard and training agree.
    """
    if feature_set not in FEATURE_SETS:
        raise KeyError(f"Unknown feature set {feature_set!r}; choose from {list(FEATURE_SETS)}")
    d = df.copy()
    d["date"] = pd.to_datetime(d["date"])
    doy = d["date"].dt.dayofyear.to_numpy(dtype=float)
    d["doy_sin"] = np.sin(2 * np.pi * doy / 365.25)
    d["doy_cos"] = np.cos(2 * np.pi * doy / 365.25)
    if {"wind_u", "wind_v"}.issubset(d.columns):
        d["wind_speed"] = np.hypot(d["wind_u"], d["wind_v"])
    cols = FEATURE_SETS[feature_set]
    missing = [c for c in cols if c not in d.columns]
    if missing:
        raise ValueError(f"Missing input columns for feature set {feature_set!r}: {missing}")
    return d[cols].reset_index(drop=True)


INPUT_LABELS = {"no2_umol_m2": "NO₂", "wind_u": "Wind u", "wind_v": "Wind v"}


def validate_inputs(reference: pd.DataFrame, values: dict[str, float], city: str) -> list[str]:
    """Return a list of problems (empty = valid). Values must be finite and inside
    the range observed for that city in the reference (training) data."""
    problems = []
    for col, label in INPUT_LABELS.items():
        lo, hi = float(reference[col].min()), float(reference[col].max())
        v = values.get(col)
        if v is None or not np.isfinite(v) or not (lo <= v <= hi):
            problems.append(f"{label} must be between {lo:.2f} and {hi:.2f} (range observed in {city}).")
    return problems


def build_preprocessor(feature_set: str = "full") -> ColumnTransformer:
    cols = FEATURE_SETS[feature_set]
    numeric = [c for c in cols if c not in CATEGORICAL]
    cats = [c for c in cols if c in CATEGORICAL]
    return ColumnTransformer(
        [
            ("num", StandardScaler(), numeric),
            ("cat", OneHotEncoder(handle_unknown="ignore"), cats),
        ]
    )
