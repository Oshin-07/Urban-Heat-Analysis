"""Loading, validating, reshaping and cleaning the three raw CSV files."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from . import config as C

SEASON_OF_MONTH = {
    12: "Winter", 1: "Winter", 2: "Winter",
    3: "Summer", 4: "Summer", 5: "Summer",
    6: "Monsoon", 7: "Monsoon", 8: "Monsoon", 9: "Monsoon",
    10: "Post-monsoon", 11: "Post-monsoon",
}


def _expected_columns() -> dict[str, list[str]]:
    sites = [f"{c}_{z}" for c in C.CITIES for z in C.ZONES]
    return {
        "lst": sites,
        "no2": [f"{s}_NO2" for s in sites],
        "wind": [f"{s}_{k}" for s in sites for k in ("u", "v", "speed")],
    }


def load_raw(raw_dir: Path | str = C.RAW_DIR) -> dict[str, pd.DataFrame]:
    """Read the three raw CSVs and validate them. Raises clear errors."""
    raw_dir = Path(raw_dir)
    expected = _expected_columns()
    out: dict[str, pd.DataFrame] = {}
    for key, fname in C.RAW_FILES.items():
        path = raw_dir / fname
        if not path.exists():
            raise FileNotFoundError(
                f"Missing raw file: {path}. Put the three CSVs from ML_Dataset.zip "
                f"into {raw_dir}."
            )
        df = pd.read_csv(path)
        if "date" not in df.columns:
            raise ValueError(f"{fname}: no 'date' column")
        df["date"] = pd.to_datetime(df["date"], errors="coerce")
        if df["date"].isna().any():
            raise ValueError(f"{fname}: unparseable dates found")
        if df["date"].duplicated().any():
            raise ValueError(f"{fname}: duplicate dates found")
        missing = [c for c in expected[key] if c not in df.columns]
        if missing:
            raise ValueError(f"{fname}: missing expected columns {missing}")
        out[key] = df.sort_values("date").reset_index(drop=True)
    d0 = out["lst"]["date"]
    for key in ("no2", "wind"):
        if not d0.equals(out[key]["date"]):
            raise ValueError(f"Dates in {C.RAW_FILES[key]} do not match the LST file")
    return out


def build_long(raw: dict[str, pd.DataFrame]) -> pd.DataFrame:
    """Wide -> long: one row per (date, city, zone)."""
    parts = []
    for city in C.CITIES:
        for zone in C.ZONES:
            site = f"{city}_{zone}"
            part = pd.DataFrame(
                {
                    "date": raw["lst"]["date"],
                    "city": city,
                    "zone": zone,
                    "lst_c": raw["lst"][site],
                    "no2_umol_m2": raw["no2"][f"{site}_NO2"],
                    "wind_u": raw["wind"][f"{site}_u"],
                    "wind_v": raw["wind"][f"{site}_v"],
                    "wind_speed_file": raw["wind"][f"{site}_speed"],
                }
            )
            parts.append(part)
    long = pd.concat(parts, ignore_index=True)
    return long.sort_values(["date", "city", "zone"]).reset_index(drop=True)


def flag_lst_outliers(
    long: pd.DataFrame,
    window: int = C.ROLL_WINDOW,
    thr: float = C.OUTLIER_THRESHOLD_C,
) -> pd.DataFrame:
    """Flag implausible LST values (observations are flagged, never altered).

    Deviation = LST minus centred rolling median of the same site.
      * cold flag : deviation < -thr  (cloud contamination biases LST low)
      * hot flag  : deviation > +thr AND the paired urban/rural site of the same
                    city did not also jump (> thr/2). A real heatwave shows up at
                    both sites and is therefore kept.
    """
    df = long.sort_values(["city", "zone", "date"]).reset_index(drop=True)
    df["lst_rollmed"] = df.groupby(["city", "zone"])["lst_c"].transform(
        lambda s: s.rolling(window, center=True, min_periods=window // 2 + 1).median()
    )
    df["lst_dev"] = df["lst_c"] - df["lst_rollmed"]
    sister = df[["date", "city", "zone", "lst_dev"]].copy()
    sister["zone"] = sister["zone"].map({"Urban": "Rural", "Rural": "Urban"})
    sister = sister.rename(columns={"lst_dev": "sister_dev"})
    df = df.merge(sister, on=["date", "city", "zone"], how="left")
    cold = df["lst_dev"] < -thr
    hot = (df["lst_dev"] > thr) & (df["sister_dev"].fillna(0.0) <= thr / 2)
    df["lst_outlier"] = (cold | hot).astype(bool)
    return df.drop(columns=["sister_dev"]).sort_values(["date", "city", "zone"]).reset_index(drop=True)


def add_calendar(df: pd.DataFrame) -> pd.DataFrame:
    d = df.copy()
    d["year"] = d["date"].dt.year
    d["month"] = d["date"].dt.month
    d["doy"] = d["date"].dt.dayofyear
    d["season"] = d["month"].map(SEASON_OF_MONTH)
    return d


def interpolation_share(raw_lst: pd.DataFrame) -> dict[str, float]:
    """Share of days lying exactly on a straight line between neighbours."""
    out = {}
    for c in raw_lst.columns:
        if c == "date":
            continue
        d2 = raw_lst[c].diff().diff().abs() < 1e-9
        out[c] = round(float(d2.sum()) / (len(raw_lst) - 2), 4)
    return out


def clean_dataset(raw_dir: Path | str = C.RAW_DIR) -> tuple[pd.DataFrame, dict]:
    raw = load_raw(raw_dir)
    long = add_calendar(flag_lst_outliers(build_long(raw)))
    n_unit_blank = int(raw["no2"]["unit"].isna().sum()) if "unit" in raw["no2"] else 0
    flagged = (
        long[long["lst_outlier"]]
        .assign(site=lambda d: d["city"] + "_" + d["zone"])
        .groupby("site")
        .size()
        .to_dict()
    )
    report = {
        "n_days": int(raw["lst"].shape[0]),
        "date_min": str(long["date"].min().date()),
        "date_max": str(long["date"].max().date()),
        "n_rows_long": int(len(long)),
        "missing_values_after_load": int(
            long[["lst_c", "no2_umol_m2", "wind_u", "wind_v"]].isna().sum().sum()
        ),
        "duplicate_date_site_rows": int(long.duplicated(["date", "city", "zone"]).sum()),
        "no2_unit_blank_rows_dropped_column": n_unit_blank,
        "lst_outliers_flagged_total": int(long["lst_outlier"].sum()),
        "lst_outliers_flagged_by_site": flagged,
        "interpolated_day_share_by_site": interpolation_share(raw["lst"]),
        "outlier_rule": f"cold: dev<-{C.OUTLIER_THRESHOLD_C}C vs {C.ROLL_WINDOW}-day centred median; "
        f"hot: dev>+{C.OUTLIER_THRESHOLD_C}C and paired site not also >{C.OUTLIER_THRESHOLD_C / 2}C",
    }
    return long, report


def save_clean(long: pd.DataFrame, report: dict) -> None:
    C.PROC_DIR.mkdir(parents=True, exist_ok=True)
    C.METRIC_DIR.mkdir(parents=True, exist_ok=True)
    long.to_csv(C.PROC_DIR / "lst_long_clean.csv", index=False)
    (C.METRIC_DIR / "cleaning_report.json").write_text(json.dumps(report, indent=2))
