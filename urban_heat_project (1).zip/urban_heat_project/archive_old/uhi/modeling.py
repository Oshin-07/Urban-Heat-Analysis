"""Model zoo, time-aware validation, metrics and baselines."""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.dummy import DummyRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import GridSearchCV
from sklearn.neighbors import KNeighborsRegressor
from sklearn.pipeline import Pipeline
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor

from . import config as C
from .features import TARGET, build_preprocessor, make_features


def split_by_time(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Chronological split. No random shuffling (daily data are autocorrelated)."""
    year = df["date"].dt.year
    train = df[year <= C.TRAIN_END_YEAR].reset_index(drop=True)
    test = df[year == C.TEST_YEAR].reset_index(drop=True)
    if train.empty or test.empty:
        raise ValueError("Train or test set is empty; check TRAIN_END_YEAR / TEST_YEAR")
    return train, test


def year_folds(train: pd.DataFrame, val_years=None) -> list[tuple[np.ndarray, np.ndarray]]:
    """Expanding-window CV: train on all earlier years, validate on the next year."""
    val_years = val_years or C.CV_VALIDATION_YEARS
    year = train["date"].dt.year.to_numpy()
    folds = []
    for vy in val_years:
        tr = np.where(year < vy)[0]
        va = np.where(year == vy)[0]
        if len(tr) == 0 or len(va) == 0:
            raise ValueError(f"Empty fold for validation year {vy}")
        folds.append((tr, va))
    return folds


def regression_metrics(y_true, y_pred) -> dict[str, float]:
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    return {
        "MAE": float(mean_absolute_error(y_true, y_pred)),
        "RMSE": float(np.sqrt(mean_squared_error(y_true, y_pred))),
        "R2": float(r2_score(y_true, y_pred)),
    }


def model_zoo() -> dict[str, tuple[object, dict]]:
    """Name -> (estimator, hyper-parameter grid), restricted to the algorithms taught in the class practicals:
    Linear Regression (Practical 3) and k-Nearest Neighbours (Practical 4). Grids are tuned with GridSearchCV."""
    return {
        "Linear Regression": (LinearRegression(), {}),
        "k-Nearest Neighbours": (
            KNeighborsRegressor(),
            {"model__n_neighbors": [3, 5, 7, 9, 15, 30], "model__weights": ["uniform", "distance"]},
        ),
    }


def extra_model_zoo() -> dict[str, tuple[object, dict]]:
    """NOT used by default: algorithms that were not taught in the practicals. Kept only so earlier results can be
    reproduced; to use them, merge this dictionary into model_zoo()."""
    return {
        "Decision Tree": (
            DecisionTreeRegressor(random_state=C.SEED),
            {"model__max_depth": [4, 8, 12, None], "model__min_samples_leaf": [5, 20]},
        ),
        "Random Forest": (
            RandomForestRegressor(n_estimators=200, random_state=C.SEED, n_jobs=1),
            {"model__max_depth": [8, None], "model__min_samples_leaf": [2, 10]},
        ),
        "Support Vector Regression": (SVR(), {"model__C": [1, 10, 50], "model__epsilon": [0.1, 0.5]}),
    }


def make_pipeline(estimator, feature_set: str) -> Pipeline:
    return Pipeline([("prep", build_preprocessor(feature_set)), ("model", estimator)])


def fit_with_grid(name: str, feature_set: str, X_train, y_train, folds, n_jobs: int = -1) -> GridSearchCV:
    estimator, grid = model_zoo()[name]
    search = GridSearchCV(
        make_pipeline(estimator, feature_set),
        param_grid=grid if grid else {},
        cv=folds,
        scoring="neg_root_mean_squared_error",
        n_jobs=n_jobs,
        refit=True,
    )
    search.fit(X_train, y_train)
    return search


class ClimatologyBaseline:
    """Predict the training-period mean LST for the same city, zone and month.

    This is the 'just know the season' benchmark that any useful model must beat.
    """

    def fit(self, df: pd.DataFrame) -> "ClimatologyBaseline":
        d = df.copy()
        d["month"] = pd.to_datetime(d["date"]).dt.month
        self.table_ = d.groupby(["city", "zone", "month"])[TARGET].mean()
        self.global_mean_ = float(d[TARGET].mean())
        return self

    def predict(self, df: pd.DataFrame) -> np.ndarray:
        month = pd.to_datetime(df["date"]).dt.month
        keys = list(zip(df["city"], df["zone"], month))
        return np.array([self.table_.get(k, self.global_mean_) for k in keys], dtype=float)


def mean_baseline(y_train) -> DummyRegressor:
    return DummyRegressor(strategy="mean").fit(np.zeros((len(y_train), 1)), y_train)


def city_holdout(usable: pd.DataFrame, feature_set: str = "full") -> pd.DataFrame:
    """Train on one city (all years), test on the other: tests spatial transfer."""
    rows = []
    for train_city in C.CITIES:
        for test_city in C.CITIES:
            if train_city == test_city:
                continue
            tr = usable[usable["city"] == train_city]
            te = usable[usable["city"] == test_city]
            est = KNeighborsRegressor(n_neighbors=5)  # Practical 4
            # City is a constant column within the training city, so drop it from inputs.
            cols = [c for c in make_features(tr, feature_set).columns if c != "city"]
            Xtr = make_features(tr, feature_set)[cols]
            Xte = make_features(te, feature_set)[cols]
            from sklearn.compose import ColumnTransformer
            from sklearn.preprocessing import OneHotEncoder, StandardScaler

            numeric = [c for c in cols if c not in ("city", "zone")]
            cats = [c for c in cols if c == "zone"]
            prep = ColumnTransformer(
                [("num", StandardScaler(), numeric), ("cat", OneHotEncoder(handle_unknown="ignore"), cats)]
            )
            pipe = Pipeline([("prep", prep), ("model", est)]).fit(Xtr, tr[TARGET])
            m = regression_metrics(te[TARGET], pipe.predict(Xte))
            rows.append({"train_city": train_city, "test_city": test_city, "model": "k-Nearest Neighbours (k=5)", **m})
    return pd.DataFrame(rows)
