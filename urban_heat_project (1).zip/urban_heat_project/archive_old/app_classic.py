"""Streamlit dashboard: Urban Heat Analysis (Delhi & Bangalore).

Run:  streamlit run app.py
"""
from __future__ import annotations

import json

import joblib
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from uhi import config as C
from uhi.features import make_features, validate_inputs

st.set_page_config(page_title="Urban Heat Analysis", page_icon="🌡️", layout="wide")

PAGES = [
    "Home & Overview",
    "Data Explorer",
    "Urban Heat Analysis",
    "Geographic Analysis",
    "Machine-Learning Results",
    "Prediction Interface",
    "About & Methodology",
]
MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
SITE_ORDER = [f"{c} {z}" for c in C.CITIES for z in C.ZONES]
SITE_COLORS = {f"{c} {z}": C.CITY_COLORS[c] for c in C.CITIES for z in C.ZONES}
SITE_DASH = {f"{c} {z}": ("solid" if z == "Urban" else "dash") for c in C.CITIES for z in C.ZONES}


# ----------------------------------------------------------------- loaders
@st.cache_data(show_spinner="Loading cleaned dataset…")
def load_data() -> pd.DataFrame | None:
    p = C.PROC_DIR / "lst_long_clean.csv"
    if not p.exists():
        return None
    df = pd.read_csv(p, parse_dates=["date"])
    df["site"] = df["city"] + " " + df["zone"]
    return df


@st.cache_data
def load_csv(name: str) -> pd.DataFrame | None:
    p = C.METRIC_DIR / name
    return pd.read_csv(p) if p.exists() else None


@st.cache_data
def load_json(name: str) -> dict | None:
    p = C.METRIC_DIR / name
    return json.loads(p.read_text()) if p.exists() else None


@st.cache_resource(show_spinner="Loading trained model…")
def load_model():
    p = C.MODEL_DIR / "best_model.joblib"
    return joblib.load(p) if p.exists() else None


def need_data() -> pd.DataFrame:
    df = load_data()
    if df is None:
        st.error(
            "Cleaned dataset not found. Open a terminal in the project folder and run "
            "`python 01_clean_data.py`, then refresh this page."
        )
        st.stop()
    return df


def usable(df: pd.DataFrame) -> pd.DataFrame:
    return df[~df["lst_outlier"]]


def style(fig: go.Figure, h: int = 420) -> go.Figure:
    fig.update_layout(height=h, margin=dict(l=10, r=10, t=50, b=10), legend_title_text="")
    return fig


# ------------------------------------------------------------------- pages
def page_home() -> None:
    df = need_data()
    u = usable(df)
    st.title("🌡️ Urban Heat Analysis: Delhi & Bangalore")
    st.write(
        "Daily **land surface temperature (LST)** for urban and rural areas of two Indian cities "
        "(2020–2025), together with satellite NO₂ and wind data. This dashboard explores the data, "
        "compares the sites, and shows how well machine-learning models can predict LST."
    )
    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Cities", df["city"].nunique())
    c2.metric("Sites (city × zone)", df["site"].nunique())
    c3.metric("Daily records", f"{len(df):,}")
    c4.metric("Mean LST", f"{u['lst_c'].mean():.1f} °C")
    c5.metric("Flagged outliers", int(df["lst_outlier"].sum()))
    st.caption(f"Period: {df['date'].min():%d %b %Y} – {df['date'].max():%d %b %Y}. Statistics exclude flagged outliers.")

    st.subheader("Key temperature statistics")
    stats = (
        u.groupby("site")["lst_c"]
        .agg(Mean="mean", Median="median", Std="std", Min="min", Max="max")
        .reindex(SITE_ORDER)
        .round(2)
    )
    st.dataframe(stats, width="stretch")
    st.info(
        "**How to use:** pick a section in the left sidebar. *Data Explorer* filters and downloads data, "
        "*Urban Heat Analysis* compares sites and trends, *Machine-Learning Results* shows model scores, "
        "and *Prediction Interface* estimates LST from user inputs."
    )
    st.warning(
        "**Data caveat:** a large share of days (about 29–51% depending on the site) lie exactly on "
        "straight lines between neighbouring days, which suggests gaps were linearly interpolated before "
        "this dataset was supplied. Treat daily values as smoothed estimates, not independent measurements."
    )


def page_explorer() -> None:
    df = need_data()
    st.header("Data Explorer")
    f1, f2, f3 = st.columns([2, 2, 3])
    cities = f1.multiselect("City", sorted(df["city"].unique()), default=sorted(df["city"].unique()))
    zones = f2.multiselect("Zone", sorted(df["zone"].unique()), default=sorted(df["zone"].unique()))
    dmin, dmax = df["date"].min().date(), df["date"].max().date()
    rng = f3.date_input("Date range", value=(dmin, dmax), min_value=dmin, max_value=dmax)
    if not (isinstance(rng, (tuple, list)) and len(rng) == 2):
        st.info("Select both a start and an end date.")
        st.stop()
    start, end = rng
    default_cols = ["date", "city", "zone", "lst_c", "no2_umol_m2", "wind_u", "wind_v", "wind_speed_file", "lst_outlier"]
    all_cols = [c for c in df.columns if c != "site"]
    cols = st.multiselect("Columns to show", all_cols, default=default_cols)
    hide_out = st.checkbox("Hide flagged LST outliers", value=False)

    mask = (
        df["city"].isin(cities)
        & df["zone"].isin(zones)
        & (df["date"].dt.date >= start)
        & (df["date"].dt.date <= end)
    )
    if hide_out:
        mask &= ~df["lst_outlier"]
    view = df.loc[mask]
    if not cols:
        st.warning("Choose at least one column.")
        st.stop()
    if view.empty:
        st.warning("No rows match these filters. Widen the date range or select more cities/zones.")
        st.stop()
    view = view[cols]
    st.write(f"**{len(view):,}** rows match (showing the first 1,000).")
    st.dataframe(view.head(1000), width="stretch", height=380)
    st.download_button(
        "⬇️ Download filtered data as CSV",
        data=view.to_csv(index=False).encode("utf-8"),
        file_name="filtered_lst_data.csv",
        mime="text/csv",
    )
    with st.expander("Column meanings"):
        st.markdown(
            "- `lst_c`: land surface temperature, °C (daily)\n"
            "- `no2_umol_m2`: tropospheric NO₂ column, µmol/m²\n"
            "- `wind_u` / `wind_v`: east–west / north–south wind components, m/s (positive = towards east / north)\n"
            "- `wind_speed_file`: wind speed as supplied in the raw file\n"
            "- `lst_rollmed`, `lst_dev`: 15-day rolling median and the deviation from it (used for outlier detection)\n"
            "- `lst_outlier`: True when the LST value was flagged as implausible (cloud contamination)"
        )


def page_analysis() -> None:
    df = need_data()
    u = usable(df)
    st.header("Urban Heat Analysis")
    f1, f2 = st.columns(2)
    cities = f1.multiselect("Cities", C.CITIES, default=C.CITIES, key="a_cities")
    years = f2.slider("Years", int(df["year"].min()), int(df["year"].max()), (int(df["year"].min()), int(df["year"].max())))
    d = u[u["city"].isin(cities) & u["year"].between(*years)]
    if d.empty:
        st.warning("Select at least one city.")
        st.stop()
    t1, t2, t3, t4 = st.tabs(["Site comparison", "Distributions", "Time trends", "Urban vs rural"])

    with t1:
        agg = d.groupby("site")["lst_c"].agg(["mean", "median", "max", "min"]).round(2).reindex([s for s in SITE_ORDER if s in d["site"].unique()])
        fig = px.bar(agg.reset_index(), x="site", y="mean", color="site", color_discrete_map=SITE_COLORS, labels={"mean": "Mean LST (°C)", "site": ""}, title="Mean LST by site")
        st.plotly_chart(style(fig, 360), width="stretch")
        st.dataframe(agg.rename(columns={"mean": "Mean", "median": "Median", "max": "Max", "min": "Min"}), width="stretch")
        hot, cool = agg["mean"].idxmax(), agg["mean"].idxmin()
        st.success(f"Hottest site on average: **{hot}** ({agg.loc[hot, 'mean']:.2f} °C). Coolest: **{cool}** ({agg.loc[cool, 'mean']:.2f} °C).")
        hd = d.loc[d.groupby("site")["lst_c"].idxmax(), ["site", "date", "lst_c"]].assign(date=lambda x: x["date"].dt.date).rename(columns={"lst_c": "Hottest day LST (°C)"})
        st.write("Hottest recorded day per site"); st.dataframe(hd.round(2), width="stretch", hide_index=True)

    with t2:
        kind = st.radio("Plot type", ["Histogram", "Box plot"], horizontal=True)
        if kind == "Histogram":
            fig = px.histogram(d, x="lst_c", color="site", barmode="overlay", opacity=0.55, nbins=50, color_discrete_map=SITE_COLORS, labels={"lst_c": "LST (°C)"})
        else:
            fig = px.box(d, x="site", y="lst_c", color="site", color_discrete_map=SITE_COLORS, category_orders={"site": SITE_ORDER}, labels={"lst_c": "LST (°C)", "site": ""})
        st.plotly_chart(style(fig), width="stretch")

    with t3:
        c1, c2 = st.columns(2)
        res = c1.selectbox("Aggregation", ["Daily", "Weekly", "Monthly", "Yearly"], index=2)
        roll = c2.slider("Extra smoothing (periods)", 1, 12, 1)
        rule = {"Daily": "D", "Weekly": "W", "Monthly": "MS", "Yearly": "YS"}[res]
        ts = d.pivot_table(index="date", columns="site", values="lst_c").resample(rule).mean()
        if roll > 1:
            ts = ts.rolling(roll, min_periods=1).mean()
        long = ts.reset_index().melt("date", var_name="site", value_name="lst_c").dropna()
        fig = px.line(long, x="date", y="lst_c", color="site", color_discrete_map=SITE_COLORS, line_dash="site", line_dash_map=SITE_DASH, labels={"lst_c": "LST (°C)", "date": ""})
        st.plotly_chart(style(fig), width="stretch")
        seas = d.groupby(["city", "season"])["lst_c"].mean().round(1).unstack().reindex(columns=["Winter", "Summer", "Monsoon", "Post-monsoon"])
        st.write("Mean LST by season (°C)"); st.dataframe(seas, width="stretch")

    with t4:
        w = d.pivot_table(index=["date", "city"], columns="zone", values="lst_c").dropna().reset_index()
        w["Urban − Rural (°C)"] = w["Urban"] - w["Rural"]
        w["month"] = w["date"].dt.month
        m = w.groupby(["city", "month"])["Urban − Rural (°C)"].mean().reset_index()
        m["Month"] = m["month"].map(lambda i: MONTHS[i - 1])
        fig = px.line(m, x="Month", y="Urban − Rural (°C)", color="city", markers=True, color_discrete_map=C.CITY_COLORS, category_orders={"Month": MONTHS})
        fig.add_hline(y=0, line_color="black", line_width=1)
        st.plotly_chart(style(fig), width="stretch")
        st.caption("Positive values mean the urban area is warmer than the rural area. Differences are small (a fraction of a °C on average); see About & Methodology.")

    st.download_button("⬇️ Download these data (CSV)", d.drop(columns=["site"]).to_csv(index=False).encode("utf-8"), "urban_heat_selection.csv", "text/csv")


def page_geo() -> None:
    df = need_data()
    u = usable(df)
    st.header("Geographic Analysis")
    st.info(
        "The supplied dataset contains **no coordinates or boundaries**, only city and urban/rural labels. "
        "So no pixel-level map can be drawn. The map below places each city's mean LST at an **approximate "
        "city-centre reference point** (added for orientation; it is not the study-area extent)."
    )
    g = u.groupby("city")["lst_c"].mean().reset_index()
    g["lat"] = g["city"].map(lambda c: C.CITY_CENTRES[c][0])
    g["lon"] = g["city"].map(lambda c: C.CITY_CENTRES[c][1])
    g["Mean LST (°C)"] = g["lst_c"].round(2)
    try:
        fig = px.scatter_map(g, lat="lat", lon="lon", size="Mean LST (°C)", color="city", color_discrete_map=C.CITY_COLORS, hover_name="city", hover_data={"lat": False, "lon": False, "Mean LST (°C)": True}, zoom=3.6, size_max=28, map_style="open-street-map")
        st.plotly_chart(style(fig, 500), width="stretch")
    except Exception as e:  # map tiles need internet in the browser
        st.warning(f"Map could not be drawn ({e}). Showing the table instead.")
    st.dataframe(g[["city", "Mean LST (°C)"]], width="stretch", hide_index=True)
    st.markdown(
        "**Spatial pattern supported by the data:** Bangalore (south, plateau climate) has a higher and much "
        "more stable LST than Delhi (north, continental climate), whose LST swings strongly between winter and summer. "
        "Within each city the urban site is on average only slightly warmer than the rural site."
    )
    sd = u.groupby("city")["lst_c"].std().round(2)
    st.write("Standard deviation of LST (°C)"); st.dataframe(sd.to_frame("Std dev"), width="stretch")


def page_ml() -> None:
    st.header("Machine-Learning Results")
    comp = load_csv("model_comparison.csv")
    meta = load_json("best_model.json")
    if comp is None or meta is None:
        st.error("Model results not found. Run `python 03_train_models.py` first, then refresh.")
        st.stop()
    st.write(
        f"Models were tuned on **{meta['train_period'][0]} – {meta['train_period'][1]}** with expanding-window yearly "
        f"cross-validation and tested on the unseen period **{meta['test_period'][0]} – {meta['test_period'][1]}**."
    )
    full = comp[comp["feature_set"] == "full"].copy()
    base = comp[comp["feature_set"] == "baseline"]
    st.subheader("Model comparison (test set)")
    show = pd.concat([full, base]).drop(columns=["feature_set", "best_params"]).rename(columns={"cv_rmse": "CV RMSE"})
    st.dataframe(show.round(3), width="stretch", hide_index=True)
    st.success(
        f"Model selected by cross-validation: **{meta['model_name']}** "
        f"(test MAE {meta['test_metrics']['MAE']:.2f} °C, RMSE {meta['test_metrics']['RMSE']:.2f} °C, R² {meta['test_metrics']['R2']:.2f}). "
        f"Lowest test RMSE: **{meta['best_by_test_rmse']}**. The differences between the top models are small."
    )
    m = full.melt(id_vars="model", value_vars=["MAE", "RMSE"], var_name="Metric", value_name="°C")
    fig = px.bar(m, x="model", y="°C", color="Metric", barmode="group", color_discrete_sequence=["#56B4E9", "#0072B2"], labels={"model": ""})
    st.plotly_chart(style(fig, 360), width="stretch")

    pred = load_csv("test_predictions.csv")
    sel = meta["model_name"]
    if pred is not None:
        models = [c for c in pred.columns if c not in ("date", "city", "zone", "actual")]
        sel = st.selectbox("Model for the plots below", models, index=models.index(meta["model_name"]) if meta["model_name"] in models else 0)
    tabs = st.tabs(["Actual vs predicted", "Residuals", "Feature importance", "What features matter? (ablation)", "City hold-out"])
    with tabs[0]:
        if pred is None:
            st.warning("test_predictions.csv missing.")
        else:
            fig = px.scatter(pred, x="actual", y=sel, color="city", color_discrete_map=C.CITY_COLORS, opacity=0.5, labels={"actual": "Observed LST (°C)", sel: "Predicted LST (°C)"})
            lo, hi = float(pred["actual"].min()), float(pred["actual"].max())
            fig.add_trace(go.Scatter(x=[lo, hi], y=[lo, hi], mode="lines", line=dict(color="black", dash="dash"), name="Perfect prediction"))
            st.plotly_chart(style(fig), width="stretch")
            ts = pred.assign(date=pd.to_datetime(pred["date"])).query("city == 'Delhi' and zone == 'Urban'")
            fig2 = go.Figure([go.Scatter(x=ts["date"], y=ts["actual"], name="Observed", line=dict(color="black", width=1)), go.Scatter(x=ts["date"], y=ts[sel], name=sel, line=dict(color="#D55E00", width=1))])
            fig2.update_layout(title="Delhi Urban, 2025: observed vs predicted")
            st.plotly_chart(style(fig2, 340), width="stretch")
    with tabs[1]:
        if pred is not None:
            r = pred.copy()
            r["residual"] = r["actual"] - r[sel]
            fig = px.histogram(r, x="residual", color="city", color_discrete_map=C.CITY_COLORS, nbins=50, barmode="overlay", opacity=0.6, labels={"residual": "Observed − predicted (°C)"})
            st.plotly_chart(style(fig, 360), width="stretch")
            st.caption("Residuals centred away from zero indicate systematic bias, e.g. 2025 was cooler than earlier years.")
    with tabs[2]:
        imp = load_csv("feature_importance.csv")
        if imp is None:
            st.warning("feature_importance.csv missing.")
        else:
            fig = px.bar(imp.sort_values("importance_rmse_increase"), x="importance_rmse_increase", y="feature", orientation="h", error_x="std", labels={"importance_rmse_increase": "Increase in RMSE (°C) when feature is shuffled", "feature": ""})
            st.plotly_chart(style(fig, 380), width="stretch")
            st.caption("Permutation importance on the test set for the selected model. `doy_sin`/`doy_cos` together encode the time of year.")
    with tabs[3]:
        ab = comp[comp["feature_set"] != "baseline"].pivot_table(index="model", columns="feature_set", values="R2").round(3)
        st.dataframe(ab, width="stretch")
        st.caption("R² on the test year. With NO₂ and wind alone (no season) models explain nothing beyond the mean: season and city carry almost all the predictive power.")
    with tabs[4]:
        ho = load_csv("city_holdout.csv")
        if ho is not None:
            st.dataframe(ho.round(3), width="stretch", hide_index=True)
            st.caption("Training on one city and predicting the other generalises poorly: with only two cities, results should not be extrapolated to other cities.")


def page_predict() -> None:
    df = need_data()
    u = usable(df)
    st.header("Prediction Interface")
    bundle = load_model()
    if bundle is None:
        st.error("Trained model not found. Run `python 03_train_models.py` first, then refresh.")
        st.stop()
    pipe, meta = bundle["pipeline"], bundle["meta"]
    st.write(f"Model: **{meta['model_name']}** (trained on {meta['train_period'][0]} – {meta['train_period'][1]}). Enter conditions below and press *Predict*.")
    c1, c2, c3 = st.columns(3)
    city = c1.selectbox("City", C.CITIES)
    zone = c2.selectbox("Zone", C.ZONES)
    date = c3.date_input("Date (season is derived from this)", value=pd.Timestamp("2025-05-15").date())
    rng = u[u["city"] == city]
    n1, n2, n3 = st.columns(3)
    no2 = n1.number_input("NO₂ column (µmol/m²)", float(rng["no2_umol_m2"].min()), float(rng["no2_umol_m2"].max()), float(rng["no2_umol_m2"].median()), step=5.0)
    wu = n2.number_input("Wind u – eastward (m/s)", float(rng["wind_u"].min()), float(rng["wind_u"].max()), float(round(rng["wind_u"].median(), 2)), step=0.1)
    wv = n3.number_input("Wind v – northward (m/s)", float(rng["wind_v"].min()), float(rng["wind_v"].max()), float(round(rng["wind_v"].median(), 2)), step=0.1)
    st.caption(f"Inputs are limited to the range observed in {city} ({rng['date'].min():%Y}–{rng['date'].max():%Y}); the model should not be used outside it. Wind speed is computed as √(u²+v²).")

    if st.button("Predict LST", type="primary"):
        # Server-side validation (do not rely on the browser enforcing widget limits)
        problems = validate_inputs(rng, {"no2_umol_m2": no2, "wind_u": wu, "wind_v": wv}, city)
        if problems:
            st.error("Invalid input: " + " ".join(problems))
            st.stop()
        row =pd.DataFrame([{"date": pd.Timestamp(date), "city": city, "zone": zone, "no2_umol_m2": no2, "wind_u": wu, "wind_v": wv}])
        try:
            X = make_features(row, meta["feature_set"])
            pred = float(pipe.predict(X)[0])
        except Exception as e:
            st.error(f"Prediction failed: {e}")
            st.stop()
        month = pd.Timestamp(date).month
        clim = u[(u["city"] == city) & (u["zone"] == zone) & (u["month"] == month)]["lst_c"].mean()
        a, b = st.columns(2)
        a.metric("Model-predicted LST", f"{pred:.1f} °C", help="A statistical estimate, not a measurement.")
        b.metric(f"Typical observed LST, {city} {zone}, {MONTHS[month - 1]}", f"{clim:.1f} °C")
        rmse = meta["test_metrics"]["RMSE"]
        st.info(
            f"Typical error on unseen data was about ±{rmse:.1f} °C (RMSE), so treat the result as roughly "
            f"{pred - rmse:.0f}–{pred + rmse:.0f} °C. **This is a model prediction, not an observed temperature.**"
        )
        st.markdown(
            f"**Why this value?** The model relies mostly on the *time of year* ({MONTHS[month - 1]}) and the *city*; "
            "NO₂ and wind change the estimate only slightly (see feature importance on the Machine-Learning Results page)."
        )


def page_about() -> None:
    st.header("About & Methodology")
    rep = load_json("cleaning_report.json") or {}
    st.markdown(
        """
**Title:** Urban Heat Analysis Across Indian Cities Using Machine Learning

**Data:** three daily CSV files (`LST_Final_V3`, `NO2_Final_V3`, `Wind_Final_V3`), 1 Jan 2020 – 30 Dec 2025, for the
urban and rural areas of **Delhi** and **Bangalore**. LST is in °C; NO₂ is a column density in µmol/m²; wind is given as
u/v components (m/s). The files do not document the satellite sensor, the pixel size, the day/night overpass or the licence;
this must be confirmed with the data provider before publication.

**Objectives:** (1) describe and compare LST across sites and seasons; (2) quantify the urban–rural difference;
(3) test how well LST can be predicted from season, location, NO₂ and wind.

**Method:** wide→long reshaping → outlier flagging (value more than 10 °C below its 15-day rolling median, or an
uncorroborated spike above it) → exploratory analysis → five regression models (Linear, k-NN, Decision Tree, Random Forest, SVR)
with standardised numeric inputs and one-hot city/zone → hyper-parameter tuning with expanding-window yearly cross-validation
(2020–2024) → evaluation on the held-out year 2025 using MAE, RMSE and R², compared against simple baselines.

**Limitations and responsible interpretation**
- Only two cities; results do not generalise to other cities (hold-out test confirms this).
- Many daily values appear linearly interpolated, so neighbouring days are not independent.
- NO₂ and wind are same-day associations, not causes, and this is not a forecasting system.
- The urban–rural difference is small and depends on how "urban" and "rural" areas were defined, which is undocumented.
- 2025 was cooler than earlier years, so the test period is a genuine distribution shift.
- Predictions are statistical estimates with an error of roughly ±4 °C.
        """
    )
    if rep:
        with st.expander("Data-cleaning report"):
            st.json(rep)


# -------------------------------------------------------------------- main
st.sidebar.title("🌡️ Urban Heat")
page = st.sidebar.radio("Go to", PAGES, key="page")
st.sidebar.caption("Delhi & Bangalore · 2020–2025")
{
    "Home & Overview": page_home,
    "Data Explorer": page_explorer,
    "Urban Heat Analysis": page_analysis,
    "Geographic Analysis": page_geo,
    "Machine-Learning Results": page_ml,
    "Prediction Interface": page_predict,
    "About & Methodology": page_about,
}[page]()
