"""Tests for the practical-style code (uhi/practicals.py) and its page."""
import numpy as np
import pandas as pd
import pytest

from uhi import config as C
from uhi import practicals as P

READY = (C.PROC_DIR / "lst_long_clean.csv").exists()
needs = pytest.mark.skipif(not READY, reason="run 01_clean_data.py first")


@pytest.fixture(scope="module")
def parts():
    df = pd.read_csv(C.PROC_DIR / "lst_long_clean.csv", parse_dates=["date"])
    x, y = P.prepare_data(df)
    return (x, y, *P.split_data(x, y))


@needs
def test_split_is_80_20_and_outliers_dropped(parts):
    x, y, xtr, xte, ytr, yte = parts
    assert len(x) == 8764 - 28 and abs(len(xte) / len(x) - 0.2) < 0.001
    assert x.dtypes.map(lambda d: np.issubdtype(d, np.number)).all()  # LabelEncoder worked


@needs
def test_linear_regression_metrics_consistent(parts):
    x, y, xtr, xte, ytr, yte = parts
    _, pred, m, coef = P.linear_regression(xtr, ytr, xte, yte)
    assert m["RMSE"] == pytest.approx(np.sqrt(m["MSE"])) and 0 < m["R2 Score"] < 1
    assert set(coef["Feature"]) == set(P.FEATURES) - set()


@needs
def test_hand_written_knn_matches_sklearn(parts):
    x, y, xtr, xte, ytr, yte = parts
    a, b = P.scale_features(xtr, xte)
    _, sk = P.knn_sklearn(a, ytr, b, k=5)
    hand = P.KNNRegressor(5); hand.fit(a, ytr)
    assert np.allclose(hand.predict(b[:150]), sk[:150])


def test_euclidean_distance_example_from_practical_4():
    assert P.euclidean_distance(np.array([2, 3]), np.array([5, 7])) == 5.0


@needs
def test_grid_search_returns_taught_parameters(parts):
    x, y, xtr, xte, ytr, yte = parts
    g = P.grid_search_linear(xtr, ytr)
    assert set(g.best_params_) == {"fit_intercept", "copy_X", "positive"}
