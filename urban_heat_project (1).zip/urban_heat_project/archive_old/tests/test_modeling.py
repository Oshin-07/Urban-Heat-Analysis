import joblib
import numpy as np
import pandas as pd
import pytest

from uhi import config as C
from uhi.data import clean_dataset
from uhi.features import FEATURE_SETS, TARGET, build_preprocessor, make_features
from uhi.modeling import (
    ClimatologyBaseline,
    city_holdout,
    fit_with_grid,
    model_zoo,
    regression_metrics,
    split_by_time,
    year_folds,
)


@pytest.fixture(scope="module")
def usable():
    long, _ = clean_dataset()
    return long[~long["lst_outlier"]].sort_values(["date", "city", "zone"]).reset_index(drop=True)


def test_time_split_has_no_overlap_or_leakage(usable):
    train, test = split_by_time(usable)
    assert train["date"].max() < test["date"].min()
    assert train["date"].dt.year.max() == C.TRAIN_END_YEAR and set(test["date"].dt.year) == {C.TEST_YEAR}
    assert len(train) + len(test) == len(usable)


def test_cv_folds_are_strictly_chronological(usable):
    train, _ = split_by_time(usable)
    folds = year_folds(train)
    assert len(folds) == len(C.CV_VALIDATION_YEARS)
    for tr, va in folds:
        assert set(tr).isdisjoint(va)
        assert train.loc[tr, "date"].max() < train.loc[va, "date"].min()


def test_features_each_set(usable):
    for fs, cols in FEATURE_SETS.items():
        X = make_features(usable.head(50), fs)
        assert list(X.columns) == cols and len(X) == 50 and not X.isna().any().any()
    with pytest.raises(KeyError):
        make_features(usable.head(5), "nope")
    with pytest.raises(ValueError, match="Missing input columns"):
        make_features(usable.head(5).drop(columns=["no2_umol_m2"]), "full")


def test_wind_speed_recomputed_and_doy_cyclic():
    row = pd.DataFrame([{"date": "2021-12-31", "city": "Delhi", "zone": "Urban", "no2_umol_m2": 100.0, "wind_u": 3.0, "wind_v": 4.0}])
    X = make_features(row)
    assert X.loc[0, "wind_speed"] == pytest.approx(5.0)
    jan1 = make_features(row.assign(date="2022-01-01"))
    assert abs(X.loc[0, "doy_sin"] - jan1.loc[0, "doy_sin"]) < 0.05  # 31 Dec ~ 1 Jan
    assert abs(X.loc[0, "doy_cos"] - jan1.loc[0, "doy_cos"]) < 0.01


def test_metrics_against_hand_calculation():
    m = regression_metrics([1, 2, 3, 4], [1, 2, 3, 6])
    assert m["MAE"] == pytest.approx(0.5)
    assert m["RMSE"] == pytest.approx(1.0)
    assert m["R2"] == pytest.approx(1 - 4 / 5)
    assert regression_metrics([1, 2, 3], [1, 2, 3]) == {"MAE": 0.0, "RMSE": 0.0, "R2": 1.0}


def test_preprocessor_handles_unseen_category(usable):
    prep = build_preprocessor("full").fit(make_features(usable.head(200), "full"))
    row = make_features(usable.head(1).assign(city="Mumbai"), "full")
    out = prep.transform(row)  # must not raise
    assert out.shape[0] == 1


def test_climatology_baseline(usable):
    train, test = split_by_time(usable)
    clim = ClimatologyBaseline().fit(train)
    p = clim.predict(test)
    assert p.shape == (len(test),) and np.isfinite(p).all()
    manual = train[(train.city == "Delhi") & (train.zone == "Urban") & (train.date.dt.month == 5)][TARGET].mean()
    r = test[(test.city == "Delhi") & (test.zone == "Urban") & (test.date.dt.month == 5)].index[0]
    assert p[r] == pytest.approx(manual)


@pytest.mark.parametrize("name", list(model_zoo()))
def test_every_model_trains_and_predicts(usable, name):
    train, test = split_by_time(usable)
    sub = train.iloc[::12].reset_index(drop=True)  # small & fast
    folds = year_folds(sub)
    est, grid = model_zoo()[name]
    small = {k: v[:1] for k, v in grid.items()}
    from sklearn.model_selection import GridSearchCV
    from uhi.modeling import make_pipeline
    gs = GridSearchCV(make_pipeline(est, "full"), small, cv=folds, scoring="neg_root_mean_squared_error").fit(make_features(sub), sub[TARGET])
    pred = gs.predict(make_features(test.head(30)))
    assert pred.shape == (30,) and np.isfinite(pred).all()
    assert 0 < -gs.best_score_ < 15


def test_city_holdout_never_trains_on_test_city(usable):
    ho = city_holdout(usable)
    assert len(ho) == 2 and (ho.train_city != ho.test_city).all()
    assert np.isfinite(ho[["MAE", "RMSE", "R2"]].to_numpy()).all()


def test_saved_model_loads_and_reproduces_reported_metrics(usable):
    p = C.MODEL_DIR / "best_model.joblib"
    if not p.exists():
        pytest.skip("run 03_train_models.py first")
    bundle = joblib.load(p)
    _, test = split_by_time(usable)
    pred = bundle["pipeline"].predict(make_features(test, bundle["meta"]["feature_set"]))
    m = regression_metrics(test[TARGET], pred)
    for k in ("MAE", "RMSE", "R2"):
        assert m[k] == pytest.approx(bundle["meta"]["test_metrics"][k], abs=1e-6)
    # fresh single prediction through the same path the dashboard uses
    row = pd.DataFrame([{"date": pd.Timestamp("2025-05-15"), "city": "Delhi", "zone": "Urban",
                         "no2_umol_m2": 150.0, "wind_u": 0.5, "wind_v": -0.5}])
    val = float(bundle["pipeline"].predict(make_features(row, bundle["meta"]["feature_set"]))[0])
    assert 15 < val < 50
    # summer must be predicted hotter than winter for Delhi
    w = row.assign(date=pd.Timestamp("2025-01-15"))
    assert val > float(bundle["pipeline"].predict(make_features(w, bundle["meta"]["feature_set"]))[0])


def test_validate_inputs(usable):
    from uhi.features import validate_inputs
    ref = usable[usable.city == "Delhi"]
    ok = {"no2_umol_m2": float(ref.no2_umol_m2.median()), "wind_u": 0.0, "wind_v": 0.0}
    assert validate_inputs(ref, ok, "Delhi") == []
    assert len(validate_inputs(ref, {**ok, "no2_umol_m2": 1e6}, "Delhi")) == 1
    assert len(validate_inputs(ref, {**ok, "wind_u": float("nan")}, "Delhi")) == 1
    assert len(validate_inputs(ref, {**ok, "wind_v": -99.0, "wind_u": 99.0}, "Delhi")) == 2
    assert len(validate_inputs(ref, {"no2_umol_m2": 100.0}, "Delhi")) == 2   # missing keys
