"""End-to-end tests of the Streamlit dashboard using Streamlit's AppTest runner."""
import pytest
from streamlit.testing.v1 import AppTest

from uhi import config as C

PAGES = [
    "Home & Overview",
    "Data Explorer",
    "Urban Heat Analysis",
    "Geographic Analysis",
    "Machine-Learning Results",
    "Prediction Interface",
    "About & Methodology",
]

pytestmark = pytest.mark.skipif(
    not (C.PROC_DIR / "lst_long_clean.csv").exists() or not (C.MODEL_DIR / "best_model.joblib").exists(),
    reason="run 01_clean_data.py and 03_train_models.py first",
)


def fresh() -> AppTest:
    at = AppTest.from_file(str(C.ROOT / "app_classic.py"), default_timeout=90)
    at.run()
    return at


def go(at: AppTest, page: str) -> AppTest:
    at.sidebar.radio(key="page").set_value(page).run()
    return at


def test_home_loads():
    at = fresh()
    assert not at.exception
    assert at.title[0].value.startswith("🌡️")
    metrics = {m.label: m.value for m in at.metric}
    assert metrics["Cities"] == "2" and metrics["Sites (city × zone)"] == "4"
    assert metrics["Daily records"] == "8,764" and metrics["Flagged outliers"] == "28"


@pytest.mark.parametrize("page", PAGES)
def test_every_page_renders_without_error(page):
    at = go(fresh(), page)
    assert not at.exception, [e.message for e in at.exception]
    assert len(at.header) + len(at.title) >= 1


def test_explorer_filters():
    at = go(fresh(), "Data Explorer")
    assert "8,764" in at.markdown[0].value or any("8,764" in m.value for m in at.markdown)
    at.multiselect[0].set_value(["Delhi"]).run()           # city filter
    assert not at.exception
    assert any("4,382" in m.value for m in at.markdown)
    at.multiselect[1].set_value(["Urban"]).run()
    assert any("2,191" in m.value for m in at.markdown)
    at.checkbox[0].check().run()                           # hide outliers
    assert any("2,17" in m.value for m in at.markdown)     # 2,191 minus flagged Delhi Urban (16)


def test_explorer_empty_selection_is_handled():
    at = go(fresh(), "Data Explorer")
    at.multiselect[0].set_value([]).run()
    assert not at.exception
    assert any("No rows match" in w.value for w in at.warning)
    at.multiselect[0].set_value(["Delhi"]).run()
    at.multiselect[2].set_value([]).run()                  # no columns
    assert not at.exception and any("at least one column" in w.value for w in at.warning)


def test_analysis_controls():
    at = go(fresh(), "Urban Heat Analysis")
    at.selectbox[0].set_value("Yearly").run()
    assert not at.exception
    at.multiselect[0].set_value([]).run()
    assert not at.exception and any("at least one city" in w.value for w in at.warning)


def test_prediction_workflow():
    at = go(fresh(), "Prediction Interface")
    at.button[0].click().run()
    assert not at.exception, [e.message for e in at.exception]
    m = {x.label: x.value for x in at.metric}
    pred = float(m["Model-predicted LST"].split()[0])
    assert 15 < pred < 50
    # winter vs summer for Delhi: summer must be hotter
    import datetime as dt
    at.date_input[0].set_value(dt.date(2025, 1, 15)).run()
    at.button[0].click().run()
    winter = float({x.label: x.value for x in at.metric}["Model-predicted LST"].split()[0])
    assert pred > winter
    assert any("not an observed temperature" in i.value for i in at.info)


def test_prediction_inputs_are_range_limited():
    at = go(fresh(), "Prediction Interface")
    ni = at.number_input[0]
    assert ni.min < ni.max and ni.value >= ni.min and ni.value <= ni.max
    default = ni.value
    at.number_input[0].set_value(ni.max + 1000).run()      # try to bypass the browser limit
    # Streamlit rejects the out-of-range value and keeps the last valid one
    assert not at.exception and at.number_input[0].value == default
    at.button[0].click().run()
    assert not at.exception
    pred = float({m.label: m.value for m in at.metric}["Model-predicted LST"].split()[0])
    assert 15 < pred < 50
