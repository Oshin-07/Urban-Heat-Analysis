import numpy as np
import pandas as pd
import pytest

from uhi import config as C
from uhi.data import add_calendar, build_long, clean_dataset, flag_lst_outliers, load_raw


@pytest.fixture(scope="module")
def raw():
    return load_raw()


@pytest.fixture(scope="module")
def cleaned():
    return clean_dataset()


def test_raw_files_load_and_align(raw):
    assert set(raw) == {"lst", "no2", "wind"}
    assert len(raw["lst"]) == 2191
    assert raw["lst"]["date"].equals(raw["no2"]["date"]) and raw["lst"]["date"].equals(raw["wind"]["date"])


def test_missing_file_gives_clear_error(tmp_path):
    with pytest.raises(FileNotFoundError, match="Missing raw file"):
        load_raw(tmp_path)


def test_long_shape_and_uniqueness(raw):
    long = build_long(raw)
    assert len(long) == 2191 * 4
    assert not long.duplicated(["date", "city", "zone"]).any()
    assert set(long["city"]) == set(C.CITIES) and set(long["zone"]) == set(C.ZONES)
    assert long[["lst_c", "no2_umol_m2", "wind_u", "wind_v"]].notna().all().all()


def test_long_values_match_wide_source(raw):
    long = build_long(raw)
    rng = np.random.default_rng(0)
    for i in rng.integers(0, 2191, 25):
        date = raw["lst"].loc[i, "date"]
        for city in C.CITIES:
            for zone in C.ZONES:
                row = long[(long.date == date) & (long.city == city) & (long.zone == zone)].iloc[0]
                s = f"{city}_{zone}"
                assert row.lst_c == raw["lst"].loc[i, s]
                assert row.no2_umol_m2 == raw["no2"].loc[i, s + "_NO2"]
                assert row.wind_u == raw["wind"].loc[i, s + "_u"]
                assert row.wind_v == raw["wind"].loc[i, s + "_v"]


def test_known_outliers_flagged_and_heatwave_kept(cleaned):
    long, report = cleaned
    q = lambda d, c, z: long[(long.date == d) & (long.city == c) & (long.zone == z)].iloc[0]
    assert q("2022-01-08", "Delhi", "Rural").lst_outlier          # -10.3 C
    assert q("2024-02-04", "Delhi", "Urban").lst_outlier          # -4.5 C
    assert q("2021-09-16", "Delhi", "Urban").lst_outlier          # 0.1 C in monsoon
    assert not q("2022-05-14", "Delhi", "Urban").lst_outlier      # real heatwave (both sites hot)
    assert not q("2022-05-14", "Delhi", "Rural").lst_outlier
    assert not q("2020-01-01", "Delhi", "Urban").lst_outlier
    assert report["lst_outliers_flagged_total"] == int(long["lst_outlier"].sum()) == 28


def test_outlier_flagging_never_changes_values(raw):
    base = build_long(raw)
    flagged = flag_lst_outliers(base)
    merged = base.merge(flagged, on=["date", "city", "zone"], suffixes=("_a", "_b"))
    assert len(merged) == len(base)
    assert (merged["lst_c_a"] == merged["lst_c_b"]).all()


def test_synthetic_spike_logic():
    dates = pd.date_range("2021-01-01", periods=40)
    rows = []
    for zone in C.ZONES:
        rows.append(pd.DataFrame({"date": dates, "city": "Delhi", "zone": zone, "lst_c": 20.0,
                                  "no2_umol_m2": 1.0, "wind_u": 0.0, "wind_v": 0.0, "wind_speed_file": 0.0}))
    long = pd.concat(rows, ignore_index=True)
    # isolated hot spike in Urban only -> flagged; same spike in both -> kept; cold spike -> flagged
    long.loc[(long.zone == "Urban") & (long.date == dates[5]), "lst_c"] = 40.0
    long.loc[long.date == dates[15], "lst_c"] = 40.0
    long.loc[(long.zone == "Rural") & (long.date == dates[25]), "lst_c"] = 5.0
    out = flag_lst_outliers(long).set_index(["date", "zone"])["lst_outlier"]
    assert out[(dates[5], "Urban")]
    assert not out[(dates[15], "Urban")] and not out[(dates[15], "Rural")]
    assert out[(dates[25], "Rural")]
    assert out.sum() == 2


def test_calendar_features(cleaned):
    long, _ = cleaned
    assert long["month"].between(1, 12).all()
    assert set(long["season"]) == {"Winter", "Summer", "Monsoon", "Post-monsoon"}
    d = add_calendar(pd.DataFrame({"date": pd.to_datetime(["2020-07-15"])}))
    assert d.loc[0, "season"] == "Monsoon" and d.loc[0, "doy"] == 197


def test_cleaning_report_values(cleaned):
    _, report = cleaned
    assert report["missing_values_after_load"] == 0
    assert report["duplicate_date_site_rows"] == 0
    assert report["n_rows_long"] == 8764
    assert all(0 < v < 1 for v in report["interpolated_day_share_by_site"].values())
