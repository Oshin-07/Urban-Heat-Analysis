"""Step 2: exploratory data analysis. Saves figures + eda_summary.json.

Run:  python 02_eda.py
"""
import json

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from scipy import stats

from uhi import config as C
from uhi.data import SEASON_OF_MONTH

sns.set_theme(style="whitegrid", context="talk", font_scale=0.7)
MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


def save(fig, name: str) -> None:
    C.FIG_DIR.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(C.FIG_DIR / name, dpi=150)
    plt.close(fig)
    print("saved", name)


def main() -> None:
    path = C.PROC_DIR / "lst_long_clean.csv"
    if not path.exists():
        raise SystemExit("Run `python 01_clean_data.py` first.")
    raw = pd.read_csv(path, parse_dates=["date"])
    df = raw[~raw["lst_outlier"]].copy()  # usable observations
    df["site"] = df["city"] + " " + df["zone"]

    # 1. Distribution of LST per city
    fig, ax = plt.subplots(figsize=(8, 4.5))
    for city, g in df.groupby("city"):
        sns.histplot(g["lst_c"], bins=40, stat="density", alpha=0.45, color=C.CITY_COLORS[city], label=city, ax=ax)
    ax.set(xlabel="Land surface temperature (°C)", ylabel="Density", title="LST distribution by city (outliers removed)")
    ax.legend()
    save(fig, "01_lst_distribution.png")

    # 2. Box plot by site
    fig, ax = plt.subplots(figsize=(8, 4.5))
    order = [f"{c} {z}" for c in C.CITIES for z in C.ZONES]
    sns.boxplot(data=df, x="site", y="lst_c", order=order, hue="city", palette=C.CITY_COLORS, legend=False, ax=ax)
    ax.set(xlabel="", ylabel="LST (°C)", title="LST by site")
    save(fig, "02_lst_boxplot_by_site.png")

    # 3. Monthly climatology
    clim = df.groupby(["site", "month"])["lst_c"].mean().reset_index()
    fig, ax = plt.subplots(figsize=(9, 4.8))
    for site, g in clim.groupby("site"):
        city, zone = site.split()
        ax.plot(g["month"], g["lst_c"], color=C.CITY_COLORS[city], ls="-" if zone == "Urban" else "--", marker="o", ms=4, label=site)
    ax.set_xticks(range(1, 13), MONTHS)
    ax.set(ylabel="Mean LST (°C)", title="Average annual cycle of LST")
    ax.legend(ncol=2)
    save(fig, "03_monthly_climatology.png")

    # 4. Yearly mean
    yearly = df.groupby(["year", "site"])["lst_c"].mean().unstack()
    fig, ax = plt.subplots(figsize=(9, 4.5))
    yearly.plot(kind="bar", ax=ax, color=[C.CITY_COLORS[s.split()[0]] for s in yearly.columns], width=0.8)
    ax.set(xlabel="Year", ylabel="Mean LST (°C)", title="Yearly mean LST (2025 has data to 30 Dec)")
    ax.legend(ncol=2, fontsize=8)
    plt.setp(ax.get_xticklabels(), rotation=0)
    save(fig, "04_yearly_mean.png")

    # 5. Correlation heatmaps (per city; zones pooled)
    num = ["lst_c", "no2_umol_m2", "wind_u", "wind_v", "wind_speed_file"]
    nice = {"lst_c": "LST", "no2_umol_m2": "NO2", "wind_u": "Wind u", "wind_v": "Wind v", "wind_speed_file": "Wind speed"}
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.6))
    corr_store = {}
    for ax, city in zip(axes, C.CITIES):
        cm = df[df["city"] == city][num].rename(columns=nice).corr()
        corr_store[city] = cm.round(3).to_dict()
        sns.heatmap(cm, annot=True, fmt=".2f", cmap="RdBu_r", vmin=-1, vmax=1, ax=ax, cbar=False)
        ax.set_title(city)
    save(fig, "05_correlation_heatmaps.png")

    # 6. Urban heat island: urban minus rural by month
    wide = df.pivot_table(index=["date", "city"], columns="zone", values="lst_c").dropna().reset_index()
    wide["uhi"] = wide["Urban"] - wide["Rural"]
    wide["month"] = wide["date"].dt.month
    uhi_m = wide.groupby(["city", "month"])["uhi"].mean().reset_index()
    fig, ax = plt.subplots(figsize=(9, 4.5))
    for city, g in uhi_m.groupby("city"):
        ax.plot(g["month"], g["uhi"], marker="o", color=C.CITY_COLORS[city], label=city)
    ax.axhline(0, color="k", lw=0.8)
    ax.set_xticks(range(1, 13), MONTHS)
    ax.set(ylabel="Urban − Rural LST (°C)", title="Urban–rural LST difference by month")
    ax.legend()
    save(fig, "06_urban_rural_difference.png")

    # 7. LST vs NO2
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.6), sharey=False)
    for ax, city in zip(axes, C.CITIES):
        g = df[df["city"] == city]
        sns.scatterplot(data=g, x="no2_umol_m2", y="lst_c", hue="season", s=12, alpha=0.5, ax=ax)
        ax.set(title=city, xlabel="NO2 column (µmol/m²)", ylabel="LST (°C)")
    save(fig, "07_lst_vs_no2.png")

    # 8. Time series with 30-day rolling mean
    fig, ax = plt.subplots(figsize=(11, 4.6))
    for site, g in df.groupby("site"):
        city, zone = site.split()
        s = g.set_index("date")["lst_c"].rolling(30, min_periods=15).mean()
        ax.plot(s.index, s.values, color=C.CITY_COLORS[city], ls="-" if zone == "Urban" else "--", label=site, lw=1.3)
    ax.set(ylabel="LST, 30-day rolling mean (°C)", title="LST time series")
    ax.legend(ncol=2, fontsize=8)
    save(fig, "08_time_series.png")

    # 9. Flagged outliers
    fig, ax = plt.subplots(figsize=(11, 4.4))
    d = raw[raw["city"] == "Delhi"]
    for zone, mk in (("Urban", "o"), ("Rural", "s")):
        g = d[d["zone"] == zone]
        ax.plot(g["date"], g["lst_c"], lw=0.5, color="0.6")
        ax.scatter(g[g["lst_outlier"]]["date"], g[g["lst_outlier"]]["lst_c"], color="crimson", marker=mk, s=28, zorder=3)
    ax.set(ylabel="LST (°C)", title="Delhi LST with flagged cloud-contaminated observations (red)")
    save(fig, "09_flagged_outliers.png")

    # ---- Summary numbers (all computed from data) ----
    site_stats = df.groupby("site")["lst_c"].agg(["count", "mean", "median", "std", "min", "max"]).round(2)
    city_mean = df.groupby("city")["lst_c"].mean().round(2)
    summary = {
        "site_stats": site_stats.to_dict(orient="index"),
        "city_mean_lst": city_mean.to_dict(),
        "hottest_site_by_mean": site_stats["mean"].idxmax(),
        "coolest_site_by_mean": site_stats["mean"].idxmin(),
        "hottest_day_per_site": {
            s: {"date": str(g.loc[g["lst_c"].idxmax(), "date"].date()), "lst_c": round(float(g["lst_c"].max()), 2)}
            for s, g in df.groupby("site")
        },
        "correlation_by_city": corr_store,
        "season_mean_lst": df.groupby(["city", "season"])["lst_c"].mean().round(2).unstack().to_dict(orient="index"),
    }
    # Urban-rural difference: daily mean + paired test on MONTHLY means (daily data are autocorrelated)
    uhi_summary = {}
    for city, g in wide.groupby("city"):
        monthly = g.set_index("date")[["Urban", "Rural"]].resample("MS").mean().dropna()
        t, p = stats.ttest_rel(monthly["Urban"], monthly["Rural"])
        uhi_summary[city] = {
            "mean_daily_diff_c": round(float(g["uhi"].mean()), 3),
            "share_days_urban_warmer": round(float((g["uhi"] > 0).mean()), 3),
            "n_months": int(len(monthly)),
            "paired_t_on_monthly_means_p": round(float(p), 4),
        }
    summary["urban_minus_rural"] = uhi_summary
    (C.METRIC_DIR).mkdir(parents=True, exist_ok=True)
    (C.METRIC_DIR / "eda_summary.json").write_text(json.dumps(summary, indent=2, default=str))
    print(json.dumps({k: summary[k] for k in ("city_mean_lst", "hottest_site_by_mean", "coolest_site_by_mean", "urban_minus_rural")}, indent=2))


if __name__ == "__main__":
    main()
