"""Step 3: train & evaluate the regression models (chronological validation).

Run:  python 03_train_models.py
"""
import json
import time

import joblib
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import sklearn
from sklearn.inspection import permutation_importance

from uhi import config as C
from uhi import practicals as P
from uhi.features import FEATURE_SETS, TARGET, make_features
from uhi.modeling import (
    ClimatologyBaseline,
    city_holdout,
    fit_with_grid,
    mean_baseline,
    model_zoo,
    regression_metrics,
    split_by_time,
    year_folds,
)


def main() -> None:
    path = C.PROC_DIR / "lst_long_clean.csv"
    if not path.exists():
        raise SystemExit("Run `python 01_clean_data.py` first.")
    C.MODEL_DIR.mkdir(parents=True, exist_ok=True)
    C.METRIC_DIR.mkdir(parents=True, exist_ok=True)
    C.FIG_DIR.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(path, parse_dates=["date"])
    usable = df[~df["lst_outlier"]].sort_values(["date", "city", "zone"]).reset_index(drop=True)
    train, test = split_by_time(usable)
    folds = year_folds(train)
    y_train, y_test = train[TARGET], test[TARGET]
    print(f"train rows={len(train)} ({train.date.min().date()}..{train.date.max().date()}) "
          f"test rows={len(test)} ({test.date.min().date()}..{test.date.max().date()})")

    rows, fitted, test_pred = [], {}, {}

    # ---- Baselines ----
    mb = mean_baseline(y_train)
    p = mb.predict(np.zeros((len(test), 1)))
    rows.append({"feature_set": "baseline", "model": "Mean of training LST", "cv_rmse": np.nan, "best_params": "{}", **regression_metrics(y_test, p)})
    clim = ClimatologyBaseline().fit(train)
    p = clim.predict(test)
    rows.append({"feature_set": "baseline", "model": "Seasonal climatology (city+zone+month mean)", "cv_rmse": np.nan, "best_params": "{}", **regression_metrics(y_test, p)})
    test_pred["Seasonal climatology"] = p

    # ---- Models x feature sets ----
    for fs in FEATURE_SETS:
        Xtr, Xte = make_features(train, fs), make_features(test, fs)
        for name in model_zoo():
            t0 = time.time()
            search = fit_with_grid(name, fs, Xtr, y_train, folds)
            pred = search.predict(Xte)
            m = regression_metrics(y_test, pred)
            rows.append({
                "feature_set": fs, "model": name,
                "cv_rmse": float(-search.best_score_),
                "best_params": json.dumps({k.replace("model__", ""): v for k, v in search.best_params_.items()}, default=str),
                **m,
            })
            fitted[(fs, name)] = search.best_estimator_
            if fs == "full":
                test_pred[name] = pred
            print(f"[{fs:17s}] {name:27s} cvRMSE={-search.best_score_:5.2f} test RMSE={m['RMSE']:5.2f} R2={m['R2']:.3f}  ({time.time() - t0:.0f}s)")

    res = pd.DataFrame(rows)
    res.to_csv(C.METRIC_DIR / "model_comparison.csv", index=False)

    # ---- Best model: chosen on cross-validated RMSE (NOT on the test set) ----
    full = res[res["feature_set"] == "full"]
    best_name = full.loc[full["cv_rmse"].idxmin(), "model"]
    best_by_test = full.loc[full["RMSE"].idxmin(), "model"]
    best = fitted[("full", best_name)]
    best_metrics = full[full["model"] == best_name].iloc[0]
    print(f"Best by CV: {best_name} | best by test RMSE: {best_by_test}")

    meta = {
        "model_name": best_name,
        "feature_set": "full",
        "features": FEATURE_SETS["full"],
        "train_period": [str(train.date.min().date()), str(train.date.max().date())],
        "test_period": [str(test.date.min().date()), str(test.date.max().date())],
        "test_metrics": {k: float(best_metrics[k]) for k in ("MAE", "RMSE", "R2")},
        "cv_rmse": float(best_metrics["cv_rmse"]),
        "best_by_test_rmse": best_by_test,
        "sklearn_version": sklearn.__version__,
        "selection_rule": "lowest mean RMSE over expanding-window yearly CV folds on 2020-2024",
    }
    joblib.dump({"pipeline": best, "meta": meta}, C.MODEL_DIR / "best_model.joblib")
    (C.METRIC_DIR / "best_model.json").write_text(json.dumps(meta, indent=2))

    # ---- Predictions file (for dashboard plots) ----
    pred_df = test[["date", "city", "zone", TARGET]].rename(columns={TARGET: "actual"}).copy()
    for k, v in test_pred.items():
        pred_df[k] = v
    pred_df.to_csv(C.METRIC_DIR / "test_predictions.csv", index=False)

    # ---- Permutation importance on the test set (model-agnostic) ----
    Xte = make_features(test, "full")
    pi = permutation_importance(best, Xte, y_test, scoring="neg_root_mean_squared_error", n_repeats=15, random_state=C.SEED, n_jobs=1)
    imp = pd.DataFrame({"feature": Xte.columns, "importance_rmse_increase": pi.importances_mean, "std": pi.importances_std}).sort_values("importance_rmse_increase", ascending=False)
    imp.to_csv(C.METRIC_DIR / "feature_importance.csv", index=False)

    # ---- Spatial transfer: leave one city out ----
    ho = city_holdout(usable, "full")
    ho.to_csv(C.METRIC_DIR / "city_holdout.csv", index=False)

    # ---- Classroom-style workflow (Practical 3 and Practical 4), random 80/20 split as taught ----
    x_all, y_all = P.prepare_data(df)                                   # Practical 3a: LabelEncoder, x / y
    x_train, x_test, y_train_c, y_test_c = P.split_data(x_all, y_all)   # test_size=0.20, random_state=42
    _, _, m_lin, coef = P.linear_regression(x_train, y_train_c, x_test, y_test_c)   # Practical 3
    grid = P.grid_search_linear(x_train, y_train_c)                     # Practical 3a: GridSearchCV, cv=5, r2
    xs_train, xs_test = P.scale_features(x_train, x_test)               # Practical 4: StandardScaler
    _, y_knn = P.knn_sklearn(xs_train, y_train_c, xs_test, k=5)         # Practical 4: KNeighborsRegressor
    hand = P.KNNRegressor(k=5)                                          # Practical 4: KNN written by hand
    hand.fit(xs_train, y_train_c)
    y_hand = hand.predict(xs_test)
    class_rows = [
        {"model": "Linear Regression", **m_lin},
        {"model": "KNN (sklearn, k=5)", **P.regression_metrics(y_test_c, y_knn)},
        {"model": "KNN (written by hand, k=5)", **P.regression_metrics(y_test_c, y_hand)},
    ]
    pd.DataFrame(class_rows).rename(columns={"R2 Score": "R2"}).to_csv(C.METRIC_DIR / "classroom_split_results.csv", index=False)
    coef.to_csv(C.METRIC_DIR / "linear_regression_coefficients.csv", index=False)
    print("\n=== Classroom-style (random 80/20 split) ===")
    print(pd.DataFrame(class_rows).round(3).to_string(index=False))
    print("GridSearchCV (Linear Regression):", grid.best_params_, round(grid.best_score_, 3))

    # ---- Figures ----
    models = [m for m in test_pred if m != "Seasonal climatology"]
    fig, axes = plt.subplots(1, len(models), figsize=(3.4 * len(models), 3.6), sharex=True, sharey=True)
    lo, hi = float(y_test.min()), float(y_test.max())
    for ax, m in zip(np.atleast_1d(axes), models):
        ax.scatter(y_test, test_pred[m], s=6, alpha=0.4, color="#0072B2")
        ax.plot([lo, hi], [lo, hi], "k--", lw=1)
        ax.set_title(m, fontsize=9)
        ax.set_xlabel("Observed LST (°C)")
    np.atleast_1d(axes)[0].set_ylabel("Predicted LST (°C)")
    fig.tight_layout(); fig.savefig(C.FIG_DIR / "10_actual_vs_predicted.png", dpi=150); plt.close(fig)

    fig, ax = plt.subplots(figsize=(6.5, 4))
    resid = y_test.to_numpy() - test_pred[best_name]
    ax.scatter(test_pred[best_name], resid, s=6, alpha=0.4, color="#D55E00")
    ax.axhline(0, color="k", lw=1)
    ax.set(xlabel="Predicted LST (°C)", ylabel="Residual (observed − predicted, °C)", title=f"Residuals: {best_name}")
    fig.tight_layout(); fig.savefig(C.FIG_DIR / "11_residuals_best_model.png", dpi=150); plt.close(fig)

    piv = full.set_index("model")[["MAE", "RMSE"]]
    fig, ax = plt.subplots(figsize=(8, 4))
    piv.plot(kind="bar", ax=ax, color=["#56B4E9", "#0072B2"])
    ax.set(ylabel="Error on 2025 test set (°C)", title="Model comparison (full feature set)")
    plt.setp(ax.get_xticklabels(), rotation=20, ha="right")
    fig.tight_layout(); fig.savefig(C.FIG_DIR / "12_model_comparison.png", dpi=150); plt.close(fig)

    print("\n=== Test-set results (2025), full feature set ===")
    print(full[["model", "cv_rmse", "MAE", "RMSE", "R2"]].round(3).to_string(index=False))
    print("\n=== Baselines ===")
    print(res[res.feature_set == "baseline"][["model", "MAE", "RMSE", "R2"]].round(3).to_string(index=False))
    print("\n=== Permutation importance (best model) ===")
    print(imp.round(3).to_string(index=False))
    print("\n=== City hold-out ===")
    print(ho.round(3).to_string(index=False))


if __name__ == "__main__":
    main()
