"""Checks the saved results of 03_train_models.py."""
import json

import joblib
import numpy as np
import pandas as pd
import pytest

from uhi import config as C

READY = (C.METRIC_DIR / "model_results.csv").exists() and (C.MODEL_DIR / "best_model.joblib").exists()
pytestmark = pytest.mark.skipif(not READY, reason="run 03_train_models.py first")

MODELS = ["Linear Regression", "KNN Regression", "Decision Tree", "Random Forest", "SVR", "Gradient Boosting"]


def test_six_models_with_consistent_metrics():
    r = pd.read_csv(C.METRIC_DIR / "model_results.csv")
    assert list(r["Model"]) == MODELS
    assert np.allclose(r["RMSE"], np.sqrt(r["MSE"]))
    assert (r["R2"] < 1).all() and r["CV R2"].notna().all()


def test_best_model_has_highest_cv_r2():
    r = pd.read_csv(C.METRIC_DIR / "model_results.csv").set_index("Model")
    meta = json.loads((C.METRIC_DIR / "best_model.json").read_text())
    assert meta["model_name"] == r["CV R2"].idxmax()
    assert meta["metrics"]["R2"] == pytest.approx(r.loc[meta["model_name"], "R2"])


def test_unseen_year_scores_are_lower_than_random_split():
    r = pd.read_csv(C.METRIC_DIR / "model_results.csv")
    assert (r["R2 2025"] <= r["R2"]).all()


def test_predictions_and_importance_files():
    p = pd.read_csv(C.METRIC_DIR / "predictions.csv")
    assert set(MODELS).issubset(p.columns) and len(p) == 1748
    imp = pd.read_csv(C.METRIC_DIR / "feature_importance.csv")
    assert len(imp) == 7 and imp["importance_rmse_increase"].max() > 0


def test_saved_model_predicts_a_sensible_temperature():
    b = joblib.load(C.MODEL_DIR / "best_model.joblib")
    row = pd.DataFrame([{"city": "Delhi", "zone": "Urban", "season": "Summer", "month": 5, "no2_umol_m2": 120.0, "wind_u": 0.4, "wind_v": -0.5}])
    for col, le in b["encoders"].items():
        row[col] = le.transform(row[col])
    row = b["scaler"].transform(row[b["columns"]])
    assert 20 < float(b["model"].predict(row)[0]) < 50
