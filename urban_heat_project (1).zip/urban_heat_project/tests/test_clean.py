"""Checks the output of 01_clean_data.py."""
import pandas as pd
import pytest

from uhi import config as C

P = C.PROC_DIR / "lst_long_clean.csv"
pytestmark = pytest.mark.skipif(not P.exists(), reason="run 01_clean_data.py first")


@pytest.fixture(scope="module")
def df():
    return pd.read_csv(P, parse_dates=["date"])


def test_shape_and_columns(df):
    assert df.shape == (8764, 15)
    assert {"date", "city", "zone", "lst_c", "no2_umol_m2", "wind_u", "wind_v", "lst_outlier", "season", "month"} <= set(df.columns)


def test_no_missing_values_or_duplicates(df):
    assert df.isnull().sum().sum() == 0
    assert not df.duplicated(["date", "city", "zone"]).any()


def test_two_cities_two_zones_full_period(df):
    assert set(df["city"]) == {"Delhi", "Bangalore"} and set(df["zone"]) == {"Urban", "Rural"}
    assert df["date"].min() == pd.Timestamp("2020-01-01") and df["date"].max() == pd.Timestamp("2025-12-30")
    assert (df.groupby(["city", "zone"]).size() == 2191).all()


def test_28_outliers_flagged_but_values_kept(df):
    assert df["lst_outlier"].sum() == 28
    assert df["lst_c"].notna().all()


def test_season_matches_month(df):
    assert set(df[df["month"].isin([12, 1, 2])]["season"]) == {"Winter"}
    assert set(df[df["month"].isin([6, 7, 8, 9])]["season"]) == {"Monsoon"}
