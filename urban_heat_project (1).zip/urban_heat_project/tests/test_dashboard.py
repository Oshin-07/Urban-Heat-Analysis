"""Tests for the Map-First dashboard: pure helpers, every page, filters and edge cases."""
import numpy as np
import pandas as pd
import pytest
from streamlit.testing.v1 import AppTest

from dashboard import analysis as A
from dashboard import charts as ch
from uhi import config as C

READY = (C.PROC_DIR / "lst_long_clean.csv").exists() and (C.MODEL_DIR / "best_model.joblib").exists()
needs_outputs = pytest.mark.skipif(not READY, reason="run 01_clean_data.py and 03_train_models.py first")
VIEWS = ["overview", "explore", "compare", "ml_insights", "about"]


@pytest.fixture(scope="module")
def df():
    return pd.read_csv(C.PROC_DIR / "lst_long_clean.csv", parse_dates=["date"])


# ------------------------------------------------------------ pure helpers
@needs_outputs
def test_filter_blanks_but_keeps_outlier_rows(df):
    out = A.filter_data(df, hide_outliers=True)
    assert len(out) == len(df)
    assert out["lst_c"].isna().sum() == df["lst_outlier"].sum() == 28
    assert out["no2_umol_m2"].notna().all()  # NO2 untouched


@needs_outputs
def test_filter_by_city_zone_date_season(df):
    out = A.filter_data(df, cities=["Delhi"], zones=["Urban"], start="2021-01-01", end="2021-12-31", seasons=["Summer"])
    assert set(out["city"]) == {"Delhi"} and set(out["zone"]) == {"Urban"}
    assert out["date"].between("2021-01-01", "2021-12-31").all() and set(out["season"]) == {"Summer"}
    assert len(out) == 92  # Mar+Apr+May 2021


@needs_outputs
def test_city_summary_matches_raw_data(df):
    d = A.filter_data(df, hide_outliers=True)
    s = A.city_summary(d, "lst_c").set_index("city")
    assert s.loc["Delhi", "mean"] == pytest.approx(d[d.city == "Delhi"]["lst_c"].mean())
    assert s.loc["Delhi", "max"] == pytest.approx(d[d.city == "Delhi"]["lst_c"].max())
    assert s.loc["Bangalore", "n_valid"] == d[d.city == "Bangalore"]["lst_c"].notna().sum()


@needs_outputs
def test_summary_for_empty_selection_is_nan_not_crash(df):
    empty = A.filter_data(df, cities=["Delhi"], start="2030-01-01")
    assert empty.empty and A.city_summary(empty, "lst_c").empty


@needs_outputs
def test_urban_rural_gap_and_sentence(df):
    gap = A.urban_rural_gap(A.filter_data(df, hide_outliers=True))
    assert set(gap["city"]) == {"Delhi", "Bangalore"} and gap["gap"].notna().all()
    assert "warmer" in A.gap_sentence("Delhi", 28.4, 28.2)
    assert "cooler" in A.gap_sentence("X", 20.0, 21.0)
    assert "not enough" in A.gap_sentence("X", np.nan, 21.0)


@needs_outputs
def test_map_uses_reference_coordinates_and_handles_missing(df):
    d = A.filter_data(df, hide_outliers=True)
    s = A.city_summary(d, "lst_c")
    fig = ch.city_map(s, "lst_c", "mean", "Delhi", 20, 35)
    labels = [t for t in fig.data if t.mode == "text"][0]
    main = [t for t in fig.data if t.mode == "markers" and t.marker.colorscale is not None][0]
    names = [t.split("<br>")[0] for t in labels.text]
    assert set(names) == {"Delhi", "Bangalore"}
    for c, la, lo in zip(names, main.lat, main.lon):
        assert (la, lo) == C.CITY_CENTRES[c]
    # a city without valid data is drawn grey, not invented
    s2 = s.copy(); s2.loc[s2.city == "Delhi", ["mean", "n_valid"]] = [np.nan, 0]
    fig2 = ch.city_map(s2, "lst_c", "mean", None, 20, 35)
    assert any("No valid" in str(t.hovertext) for t in fig2.data)


@needs_outputs
def test_all_chart_builders_run(df):
    d = A.filter_data(df, hide_outliers=True)
    sm = A.site_stats(d, "lst_c")
    p = d[d.city == "Delhi"].pivot_table(index="date", columns="zone", values="lst_c")
    ch.stripes(p.index, {z: p[z].tolist() for z in p}, 15, 40)
    ch.heat_calendar(d[d.city == "Delhi"], "lst_c", 15, 40, "t")
    ch.trend_chart(d[["date", "city", "zone", "lst_c"]], "lst_c", 30, "t")
    ch.year_clock(A.monthly_profile(d, "lst_c"), "lst_c", "t")
    ch.dumbbell(sm, "lst_c", "t")
    ch.gap_by_month(A.urban_rural_gap(d), "lst_c", "t")


# ------------------------------------------------------------------ pages
def run_view(name: str) -> AppTest:
    at = AppTest.from_file(str(C.ROOT / "views" / f"{name}.py"), default_timeout=90)
    at.run()
    return at


@needs_outputs
@pytest.mark.parametrize("name", VIEWS)
def test_every_page_renders(name):
    at = run_view(name)
    assert not at.exception, [e.message for e in at.exception]


@needs_outputs
def test_entry_point_runs_with_navigation():
    at = AppTest.from_file(str(C.ROOT / "app.py"), default_timeout=90)
    at.run()
    assert not at.exception, [e.message for e in at.exception]
    assert any("Understanding Urban Heat Across Indian Cities" in m.value for m in at.markdown)


@needs_outputs
def test_overview_city_switch_updates_statement():
    at = run_view("overview")
    assert any("Bangalore" in m.value and "statement" in m.value for m in at.markdown) or any("Delhi" in m.value and "statement" in m.value for m in at.markdown)
    other = "Bangalore" if at.session_state["sel_city"] == "Delhi" else "Delhi"
    at.segmented_control(key="pick_overview").set_value(other).run()   # simulates a real click (fires on_change)
    assert not at.exception
    assert any(f"<b>{other}</b>" in m.value and "statement" in m.value for m in at.markdown)


@needs_outputs
def test_explore_filters_and_empty_states():
    at = run_view("explore")
    assert not at.exception
    at.multiselect(key="ex_seasons").set_value([]).run()           # empty filter -> friendly warning, no crash
    assert not at.exception and any("at least one" in w.value for w in at.warning)
    at.multiselect(key="ex_seasons").set_value(["Summer"]).run()
    assert not at.exception
    at.multiselect(key="ex_zones").set_value(["Urban"]).run()
    assert not at.exception
    at.selectbox(key="pick_explore").set_value("Bangalore").run()
    assert at.session_state["sel_city"] == "Bangalore" and not at.exception


@needs_outputs
def test_explore_date_range_without_data_is_graceful():
    at = run_view("explore")
    at.date_input(key="ex_dates").set_value((pd.Timestamp("2020-01-01").date(), pd.Timestamp("2020-01-02").date())).run()
    assert not at.exception


@needs_outputs
def test_compare_needs_two_cities_and_handles_variables():
    at = run_view("compare")
    assert not at.exception
    at.multiselect(key="cmp_cities").set_value(["Delhi"]).run()
    assert not at.exception and any("at least two" in i.value for i in at.info)
    at.multiselect(key="cmp_cities").set_value(["Delhi", "Bangalore"]).run()
    at.multiselect(key="cmp_zones").set_value(["Urban"]).run()
    assert not at.exception


@needs_outputs
def test_ml_page_shows_saved_metrics():
    import json
    meta = json.loads((C.METRIC_DIR / "best_model.json").read_text())
    at = run_view("ml_insights")
    assert not at.exception
    text = " ".join(m.value for m in at.markdown)
    assert meta["model_name"] in text and f"{meta['metrics']['R2']:.2f}" in text


@needs_outputs
def test_prediction_form_gives_estimate():
    at = run_view("ml_insights")
    at.button[0].click().run()
    assert not at.exception
    assert any("Predicted LST" in m.label for m in at.metric)
    value = float(at.metric[0].value.split()[0])
    assert 5 < value < 55
